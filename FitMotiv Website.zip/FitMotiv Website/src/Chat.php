<?php
namespace MyApp;

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

class Chat implements MessageComponentInterface {
    protected $clients;
    protected $mysqli;

    public function __construct($mysqli) {
        $this->clients = new \SplObjectStorage;
        $this->mysqli = $mysqli;
    }

    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
        echo "New connection: ({$conn->resourceId})\n";
    }

    public function onMessage(ConnectionInterface $from, $data) {
        $data = json_decode($data);
        if (!$data) {
            return;
        }

        switch ($data->action) {
            case 'fetchFriends':
                $this->fetchFriends($from, $data->userId);
                break;
            case 'fetchMessages':
                $this->fetchMessages($from, $data->conversationId);
                break;
            case 'sendMessage':
                $this->sendMessage($from, $data);
                break;
        }
    }
    private function fetchFriends($from, $userId) {
        $query = "SELECT 
                    c.id AS conversationId, 
                    IF(c.user1_id = ?, c.user2_id, c.user1_id) AS friendId, 
                    u.firstname AS firstfriendName, 
                    u.lastname AS lastfriendName, 
                    u.profilePicture AS friendPicture,
                    m.message AS lastMessage, 
                    m.created_at AS lastMessageTime,
                    COALESCE(unread.count, 0) AS unreadCount
                  FROM conversations c
                  JOIN users u ON u.id = IF(c.user1_id = ?, c.user2_id, c.user1_id)
                  LEFT JOIN messages m ON m.id = (
                      SELECT MAX(id) FROM messages WHERE conversation_id = c.id
                  )
                  LEFT JOIN (
                      SELECT conversation_id, COUNT(*) AS count
                      FROM messages
                      WHERE sender_id != ? AND read_status = 0
                      GROUP BY conversation_id
                  ) unread ON c.id = unread.conversation_id
                  WHERE c.user1_id = ? OR c.user2_id = ?";
        $stmt = $this->mysqli->prepare($query);
        if ($stmt) {
            $stmt->bind_param("iiiii", $userId, $userId, $userId, $userId, $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            $friends = [];
            while ($row = $result->fetch_assoc()) {
                $friends[] = $row;
            }
            $stmt->close();
            $from->send(json_encode(['type' => 'friends', 'data' => $friends]));
        } else {
            $from->send(json_encode(['type' => 'error', 'message' => 'Database query failed']));
        }
    }

    private function fetchMessages($from, $conversationId) {
        $query = "SELECT m.id, m.message, m.created_at, m.sender_id, u.firstname, u.lastname, u.profilePicture 
                  FROM messages m
                  JOIN users u ON u.id = m.sender_id
                  WHERE m.conversation_id = ?";
        $stmt = $this->mysqli->prepare($query);
        if ($stmt) {
            $stmt->bind_param("i", $conversationId);
            $stmt->execute();
            $result = $stmt->get_result();
            $messages = [];
            while ($row = $result->fetch_assoc()) {
                $messages[] = $row;
            }
            $stmt->close();
            $from->send(json_encode(['type' => 'messages', 'data' => $messages]));
        }
    }

    private function sendMessage($from, $data) {
        $query = "INSERT INTO messages (conversation_id, sender_id, message) VALUES (?, ?, ?)";
        $stmt = $this->mysqli->prepare($query);
        if ($stmt) {
            $stmt->bind_param("iis", $data->conversationId, $data->userId, $data->message);
            $stmt->execute();
            $inserted_id = $stmt->insert_id;
            $stmt->close();
            $fetchQuery = "SELECT m.id, m.message, m.created_at, m.sender_id, u.firstname, u.lastname, u.profilePicture
                           FROM messages m
                           JOIN users u ON u.id = m.sender_id
                           WHERE m.id = ?";
            $stmt = $this->mysqli->prepare($fetchQuery);
            if ($stmt) {
                $stmt->bind_param("i", $inserted_id);
                $stmt->execute();
                $result = $stmt->get_result();
                if ($newMessage = $result->fetch_assoc()) {
                    foreach ($this->clients as $client) {
                        $client->send(json_encode(['type' => 'new_message', 'data' => $newMessage]));
                    }
                } else {
                    echo "Failed to fetch the new message details.";
                }
                $stmt->close();
            } else {
                echo "Prepare failed: (" . $this->mysqli->errno . ") " . $this->mysqli->error;
            }
        } else {
            echo "Prepare failed: (" . $this->mysqli->errno . ") " . $this->mysqli->error;
        }
    }
    

    public function onClose(ConnectionInterface $conn) {
        $this->clients->detach($conn);
        echo "Connection {$conn->resourceId} has disconnected\n";
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";
        $conn->close();
    }
}

?>
