<?php
session_start();
include_once("./../connection/connection.php");
if (isset($_GET['action']) && $_GET['action'] == 'signUpForm') {
    $email = $_POST['email'];
    $emailCheckSql = "SELECT email FROM users WHERE email = ?";
    $stmt = $conn->prepare($emailCheckSql);
    if ($stmt === false) {
        echo json_encode(['error' => 'Failed to prepare statement for email check']);
        exit;
    }
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo json_encode(['error' => 'Email already exists']);
        $stmt->close();
        exit; 
    }
    $stmt->close(); 
    $name = $_POST['name'];
    $lastname = $_POST['lname'];
    $country = $_POST['country'];
    $city = $_POST['city'];
    $currentWeight = $_POST['current_weight'];
    $targetWeight = $_POST['targent_weight'];
    $goal = implode(",", $_POST['goal']); 
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $createdAt = date('Y-m-d H:i:s');
    $insertSql = "INSERT INTO users (firstName, lastName, email, country, city, current_weight, target_weight, goal, password, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($insertSql);
    if ($stmt === false) {
        echo json_encode(['error' => 'Failed to prepare statement for user registration']);
        exit;
    }
    $stmt->bind_param("ssssssssss", $name, $lastname, $email, $country, $city, $currentWeight, $targetWeight, $goal, $password, $createdAt);
    $success = $stmt->execute();

    if ($success) {
        echo json_encode(['success' => 'User registered successfully.']);
    } else {
        echo json_encode(['error' => 'User registration failed: ' . $stmt->error]);
    }

    $stmt->close();
}

if (isset($_POST['action']) && $_POST['action'] == 'login') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $sql = "SELECT id, firstName, lastName, password, type FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            if ($user['type'] == 1) { 
                $_SESSION['adminId'] = $user['id']; 
            } else {
                $_SESSION['userId'] = $user['id']; 
            }
            $_SESSION['firstName'] = $user['firstName'];
            $_SESSION['lastName'] = $user['lastName'];
            echo json_encode(['success' => true, 'isAdmin' => ($user['type'] == 1)]);
        } else {
            echo json_encode(['error' => 'Invalid password.']);
        }
    } else {
        echo json_encode(['error' => 'User not found.']);
    }

    $stmt->close();
}
