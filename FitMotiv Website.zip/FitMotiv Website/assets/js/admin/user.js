$(document).ready(function() {
    var table = $('#userViewTable').DataTable({
        "columns": [
            { "data": "firstname" },
            { "data": "lastname" },
            { "data": "email" },
            { "data": "bio" },
            { "data": "country" },
            { "data": "city" },
            { "data": "current_weight" },
            { "data": "target_weight" },
            { "data": "goal" },
            { "data": null, "defaultContent": "<button class='btn btn-danger delete-btn'>Delete</button>" }
        ],
        "order": [[2, "asc"]]  
    });

    $.ajax({
        url: "./../backend/admin/adminHandler.php?action=fetchUser",
        method: "GET",
        dataType: "json",
        success: function(data) {
            if (data.success) {
                table.clear();
                table.rows.add(data.users); 
                table.draw();
            }
        },
        error: function(xhr, status, error) {
            console.error('Error fetching users:', error);
        }
    });
    $('#userViewTable tbody').on('click', 'button.delete-btn', function () {
        var data = table.row($(this).parents('tr')).data();
        deleteUserData(data.id); 
    });
});

function deleteUserData(userId) {
    $.ajax({
        url: "./../backend/admin/adminHandler.php",
        type: "POST",
        data: { action: "deleteUser", userId: userId },
        success: function (response) {
            if (response.success) {
                location.reload();
                $('#userViewTable').DataTable().ajax.reload();
            } else {
                console.error('Failed to delete:', response.message);
            }
        },
        error: function (xhr, status, error) {
            console.error('Error:', error);
        }
    });
}
