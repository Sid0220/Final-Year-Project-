$(document).ready(function () {
    $("#registration_form").on('submit', function (e) {
        e.preventDefault();
        var password = $('#password').val();
        var retypePassword = $('#retypePassword').val();
        if (password !== retypePassword) {
            toastr.error('Passwords do not match!', 'Error');
            return;
        }
        var formData = $(this).serialize();
        $.ajax({
            url: './backend/auth/auth.php?action=signUpForm',
            method: 'POST',
            data: formData,
            success: function (response) {
                var data = JSON.parse(response); 
                if (data.success) {
                    toastr.success(data.success);
                    setTimeout(function() {
                        window.location.href = './index.php';
                    }, 2000);
                } else if (data.error) {
                    toastr.error(data.error);
                }
            },
            error: function (xhr, status, error) {
                toastr.error('Please try again.', 'Signup failed');
            }
        });
    });
    $("#login_form").submit(function(e) {
        e.preventDefault();

        var formData = {
            email: $('#loginEmail').val(),
            password: $('#loginPassword').val(),
            action: 'login'
        };

        $.ajax({
            url: './backend/auth/auth.php',
            type: 'POST',
            data: formData,
            success: function(response) {
                var data = JSON.parse(response);
                if(data.success) {
                    toastr.success('Login successful!');
                    
                    if(data.isAdmin){
                        window.location.href="./admin/index.php";
                    }else{
                        window.location.href="./components/index.php";
                    }
                   
                } else {
                    toastr.error(data.error ? data.error : 'Login failed. Please try again.');
                }
            },
            error: function() {
                toastr.error('Request failed. Please try again.');
            }
        });
    });
    $(document).ready(function() {
        $('#goal').select2({
          placeholder: "Select a goal", 
          allowClear: true 
        });
      });
});
