function fetchTheFriendRequest() {
    $.ajax({
        url: "./../backend/function/functionHandler.php?action=fetchRequest",
        method: "GET",
        dataType: "json",
        success: function (data) {
            console.log(data);
            if (data.success && data.requests.length > 0) {
                $("#appendFriendRequest").empty(); // Clear existing entries
                data.requests.forEach(function (request) {
                    var profilePicture = request.requester_picture ? './../uploads/' + request.requester_picture : './../assets/img/profile.png';
                    var fullName = request.requester_firstname + ' ' + request.requester_lastname; // Concatenate the full name
                    var requestHTML = `<div class="card mt-2 mb-2 custom_card">
                        <div class="card-body d-flex align-items-center justify-content-between">
                            <h4 class="card-text">
                                <img src="${profilePicture}" alt="" class="img img-fluid mr-2" id="goTOprofile" width="50rem">
                                ${fullName}
                            </h4>
                            <div>
                                <button class="btn btn-success" onclick="acceptRequest(${request.request_id})">Accept</button>
                                <button class="btn btn-danger" onclick="rejectRequest(${request.request_id})">Reject</button>
                            </div>
                        </div>
                    </div>`;
                    $("#appendFriendRequest").append(requestHTML); 
                });
            } else {
                $("#appendFriendRequest").html(`
                <div class="card mt-2 mb-2 custom_card">
                    <div class="card-body d-flex align-items-center justify-content-between">
                       <h4>No friend requests found.</h4>
                    </div>
                </div>`); 
            }
        },
        error: function () {
            $("#appendFriendRequest").html('<p>Error fetching friend requests.</p>'); 
        }
    });
}

$(document).ready(function () {
    fetchTheFriendRequest();
});

function acceptRequest(requestId) {
    $.ajax({
        url: "./../backend/function/functionHandler.php?action=acceptRequest",
        method: "POST",
        dataType: "json",
        data: { requestId: requestId },
        success: function(data) {
            console.log(data);
            if (data.success) {
                toastr.success(data.message);
                fetchTheFriendRequest();
            } else {
                toastr.error(data.message);
            }
        },
        error: function(xhr, status, error) {
            toastr.error('Failed to send friend request. Please try again.');
        }
    })
}

function rejectRequest(requestId) {
    $.ajax({
        url: "./../backend/function/functionHandler.php?action=delayFriendRequest",
        method: "POST",
        dataType: "json",
        data: { requestId: requestId },
        success: function(data) {
            console.log(data);
            if (data.success) {
                toastr.success(data.message);
                fetchTheFriendRequest();
            } else {
                toastr.error(data.message);
            }
        },
        error: function(xhr, status, error) {
            toastr.error('Failed to send friend request. Please try again.');
        }
    })
}
