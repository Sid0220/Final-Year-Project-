function addLikes(postId) {
    $.ajax({
        url: './../backend/function/functionHandler.php?action=fetchLike',
        method: "POST",
        dataType: "json",
        data: { postId: postId },
        success: function (data) {
            if (data.userLiked) {
                $(`.like-btn[data-post-id='${postId}']`).addClass('liked');
            }
            $(`.like-count[data-post-id='${postId}']`).text(data.count);
        }
    });
}
function fetchFriend() {
    $.ajax({
        url: './../backend/function/functionHandler.php?action=getAllUser',
        dataType: 'json',
        success: function (data) {
            $('#AppendhereFriends').empty();
            if (data.success && data.suggestions.length > 0) {
                $('#AppendhereFriends').empty();
                data.suggestions.forEach(function (user) {
                    console.log(user);
                    var profilePicture = user.profilePicture ? './../uploads/' + user.profilePicture : './../assets/img/profile.png';
                    var badgeHtml = `<span class="badge badge-success">${user.goal}</span>`;
                    $('#AppendhereFriends').append(
                        `<div class="d-flex align-items-center mb-3"  >
                            <img src="${profilePicture}" alt="" class="img img-fluid w-25 mr-2" id="goTOprofile" data-userid="${user.id}">
                            <div class="user-info">
                                <h5 class="user-name">${user.firstname} ${user.lastname}</h5>
                                ${badgeHtml} 
                            </div>
                            <button type="button" class="btn btn-secondary ml-auto" id="addFriendBtn" data-userid="${user.id}">
                                <i class="fas fa-user-plus"></i> 
                            </button>
                        </div>`
                    );
                });
            } else {
                $('#AppendhereFriends').append('<p>No users found.</p>');
            }
        },
        error: function (xhr, status, error) {
            console.error('Error fetching user data:', error);
            $('#AppendhereFriends').append('<p>Error fetching user data.</p>');
        }
    });
}
$(document).ready(function () {
   
    $('#post').submit(function (e) {
        e.preventDefault();
        var postText = $('#postText').val();
        if (postText.length > 300) {
            toastr.error('Your post cannot be over 300 characters.');
            return false;
        }
    
        var formData = new FormData(this);
    
        $.ajax({
            type: 'POST',
            url: './../backend/function/functionHandler.php?action=createPost',
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                var data = JSON.parse(response);
                if (data.success) {
                    toastr.success('Post submitted successfully.');
                    $('#postText').val(''); 
                    $('#uploadPhoto').val(''); 
                    $('#previewHere').empty(); 
                    fetch();
                } else {
                    toastr.error('Error: ' + data.error);
                }
            }
        });
    });
    $('#uploadPhoto').on('change', function() {
        var file = this.files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#previewHere').html('<img src="' + e.target.result + '" alt="Image Preview" style="max-width: 100%; height: auto;">');
            };
            reader.readAsDataURL(file);
        }
    });
    
    
    function getProfile() {
        $.ajax({
            url: "./../backend/function/functionHandler.php?action=postPageDetails",
            method: "POST",
            dataType: "json",
            success: function (data) {
                $("#appendProfileImage").html(` <img src="./../uploads/${data.user.profilePicture || './../assets/img/profile.png'}" alt="img profile" class="img img-fluid img_custom_banner">`);
                $("#navbarDropdownMenuLink").html(`<img src="./../uploads/${data.user.profilePicture || './../assets/img/profile.png'}" alt="profile image" class="img img-fluid img_custom rounded-circle" style="width: 40px; height: 40px;">`);
            }
        })
    }
    function fetch() {
        $.ajax({
            url: './../backend/function/functionHandler.php?action=fetchPost',
            method: "POST",
            dataType: "json",
            success: function (data) {
                $("#appendPost").empty();
                data.forEach(function (post) {
                    var postHtml = `
                    <div class="post-container">
                    <div class="d-flex" id="GetProfile" data-userid="${post.userId}">
                        <div class="post-image">
                            <img src="./../uploads/${post.profilePicture || './../assets/img/profile.png'}" alt="User Image" />
                        </div>
                        <div class="post-content ms-3">
                            <h5 class="user-name">${post.firstName} ${post.lastName}</h5>
                            <p>${post.postText}</p>
                            ${post.postImage ? `<img src="./../postImages/${post.firstName}/${post.postImage}" alt="Post Image" style="max-width: 100%; height: auto;">` : ''}
                        </div>
                    </div>
                    <div class="post-actions">
                        <button type="button" class="like-btn" data-post-id="${post.postId}" data-user-id="${post.userId}">Like</button> <span class="like-count">${post.likeCount || 0}</span>
                        <button type="button" class="comment-btn">Comment</button> <span class="comment-count">${post.comments.length || 0}</span>
                       
                    </div>
                    <div class="comments-container col-lg-12" style="display: none;">`;
    
                    post.comments.forEach(function (comment) {
                        postHtml += `
                            <div class="existing-comment">
                                <p><strong>${comment.firstName} ${comment.lastName}:</strong> ${comment.commentText}</p>
                            </div>`;
                    });
    
                    postHtml += `
                                <!-- Add a new comment -->
                                <textarea class="comment-textarea" placeholder="Write a comment..."></textarea>
                                <button class="submit-comment" data-post-id="${post.postId}" data-user-id="${post.userId}">Submit</button>
                            </div>
                        </div>
                    </div>`;
    
                    $("#appendPost").append(postHtml);
                });
                $('.like-btn').each(function () {
                    var postId = $(this).data('post-id');
                    addLikes(postId);
                });
            }
        });
    }
    
    $(document).on('click', '.comment-btn', function () {
        $(this).closest('.post-container').find('.comments-container').slideToggle();
    });
    $(document).on('click', '.like-btn', function () {
        var $this = $(this);
        var postId = $this.data('post-id');
        var userId = $this.data('user-id');
        $.ajax({
            url: './../backend/function/functionHandler.php?action=addLike',
            method: "POST",
            data: { postId: postId, userId: userId },
            success: function (response) {
                var data = JSON.parse(response);
                if (data.message === 'Like added') {
                    $this.addClass('liked');
                    $this.find('.like-count').html(data.likeCount);
                } else if (data.message === 'Like removed') {
                    $this.removeClass('liked');
                }
                fetch();
            }
        });
    });

    $(document).on('click', '.submit-comment', function () {
        var commentText = $(this).prev('.comment-textarea').val();
        var postId = $(this).data('post-id');
        var userId = $(this).data('user-id');
        $.ajax({
            url: './../backend/function/functionHandler.php?action=addComment',
            method: "POST",
            data: { userId: userId, postId: postId, commentText: commentText },
            success: function (response) {
                fetch();
                var newCommentHtml = `<p><strong>You:</strong> ${commentText}</p>`;
                $(this).closest('.comments-container').find('.existing-comments').append(newCommentHtml);
            }
        });
    });
    fetch();
    getProfile();
    $(document).on('click', '#GetProfile', function (e) {
        e.preventDefault();
        var userId = $(this).data('userid');
        window.location.href = "./userProfile.php?userId=" + userId;
    });
    

    fetchFriend();
    $(document).on('click', '#goTOprofile', function (e) {
        e.preventDefault();
        var userId = $(this).data('userid');
        window.location.href = "./userProfile.php?userId=" + userId;
    });
    $(document).on('click', '#addFriendBtn', function (e) {
        var userid = $(this).data('userid');
        $.ajax({
            url: "./../backend/function/functionHandler.php",
            method: "POST",
            data: { action: "sendFriendRequest", requestTo: userid },
            dataType: "json",
            success: function (data) {
                if (data.success) {
                    toastr.success(data.success);
                    fetchFriend();
                } else if (data.error) {
                    toastr.error(data.error);
                }
            },
            error: function (xhr, status, error) {
                toastr.error('Failed to send friend request. Please try again.');
            }
        })
    })
});
