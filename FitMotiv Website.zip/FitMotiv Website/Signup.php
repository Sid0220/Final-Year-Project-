<!doctype html>
<html lang="en">

<head>
    <title>FITMOTIV</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="./assets/css/lib/bootstrap4.css" rel="stylesheet" />
    <link href="./assets/css/lib/select2.css" rel="stylesheet" />
    <link href="./assets/css/lib/toastr.css" rel="stylesheet" />
    <link rel="stylesheet" href="./assets/css/style.css">
</head>

<body>
    <div class="container-fluid reg-bg ">
        <div class="row container-reg pt-4 pb-4 ">
            <div class="col-lg-6">
                <div class="card custom_card">
                    <h5 class="card-title card-header">Registration</h5>
                    <div class="card-body">
                        <form id="registration_form">
                            <div class="form-group">
                                <label for="name">First Name</label>
                                <input type="text" class="form-control" name="name" id="name" placeholder="Enter Your First Name" required>
                            </div>
                            <div class="form-group">
                                <label for="lname">Last Name</label>
                                <input type="text" class="form-control" name="lname" id="lname" placeholder="Enter Your Last Name" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" name="email" id="email" placeholder="Enter Your Email" required>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="country">Country</label>
                                        <input type="text" class="form-control" name="country" id="country" placeholder="Enter Your Country" required>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="city">City</label>
                                        <input type="text" class="form-control" name="city" id="city" placeholder="Enter Your City" required>
                                    </div>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="current_weight">Current weight (kg)</label>
                                        <input type="text" class="form-control" name="current_weight" id="current_weight" placeholder="Enter Your Current Weight" required>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="targent_weight">Target weight (kg)</label>
                                        <input type="text" class="form-control" name="targent_weight" id="targent_weight" placeholder="Enter Your Target Weight" required>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="goal">Goal</label>
                                <select name="goal[]" id="goal" multiple="multiple" class="form-control">
                                    <option value="">Select Goal</option>
                                    <option value="Bulk">Bulk</option>
                                    <option value="Cut">Cut</option>
                                    <option value="Maintain">Maintain</option>
                                    <option value="Loose_Body_Fat">Loose Body Fat</option>
                                    <option value="Gain_Muscle">Gain Muscle</option>
                                </select>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="password">Password</label>
                                        <input type="password" class="form-control" name="password" id="password" placeholder="**********" required>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="retypePassword">Conform Password</label>
                                        <input type="password" class="form-control" name="retypePassword" id="retypePassword" placeholder="**********" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <button type="submit" class="btn btn-secondary">Register</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Optional JavaScript -->
    <script src="./assets/js/lib/jquery.min.js"></script>
    <script src="./assets/js/lib/toastr.js"></script>
    <script src="./assets/js/lib/select2.js"></script>
    <script src="./assets/js/lib/bootstrap4.js"></script>
    <script src="./assets/js/auth/auth.js"></script>
</body>

</html>