-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 30, 2024 at 12:01 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `facebook`
--

-- --------------------------------------------------------

--
-- Table structure for table `blockeduser`
--

CREATE TABLE `blockeduser` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `blockList` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blockeduser`
--

INSERT INTO `blockeduser` (`id`, `userId`, `blockList`) VALUES
(1, 1, '[]');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `postId` int(11) NOT NULL,
  `commentText` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `userId`, `postId`, `commentText`, `created_at`) VALUES
(1, 1, 1, 'good post', '2024-04-15 16:47:43');

-- --------------------------------------------------------

--
-- Table structure for table `conversations`
--

CREATE TABLE `conversations` (
  `id` int(11) NOT NULL,
  `user1_id` int(11) NOT NULL,
  `user2_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `conversations`
--

INSERT INTO `conversations` (`id`, `user1_id`, `user2_id`, `created_at`) VALUES
(1, 1, 2, '2024-04-22 05:36:57');

-- --------------------------------------------------------

--
-- Table structure for table `diet_records`
--

CREATE TABLE `diet_records` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `section` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `name` varchar(255) NOT NULL,
  `KCAL` decimal(10,2) NOT NULL,
  `PROTg` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `diet_records`
--

INSERT INTO `diet_records` (`id`, `userId`, `section`, `date`, `name`, `KCAL`, `PROTg`) VALUES
(1, 1, 'breakfast', '2024-04-29', 'egg', 28.00, 2.60),
(2, 1, 'lunch', '2024-04-29', 'bla blaa', 28.00, 2.60),
(3, 1, 'breakfast', '2024-04-29', 'test', 28.00, 2.60),
(4, 1, 'snacks', '2024-04-29', 'test', 28.00, 2.60),
(5, 1, 'breakfast', '2024-04-30', 'test', 28.00, 2.60),
(6, 1, 'breakfast', '2024-04-30', 'test2', 28.00, 2.60);

-- --------------------------------------------------------

--
-- Table structure for table `friend_requests`
--

CREATE TABLE `friend_requests` (
  `id` int(11) NOT NULL,
  `requester_id` int(11) NOT NULL,
  `requestee_id` int(11) NOT NULL,
  `status` enum('pending','accepted','declined') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `friend_requests`
--

INSERT INTO `friend_requests` (`id`, `requester_id`, `requestee_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 'accepted', '2024-04-22 05:36:53', '2024-04-22 05:36:57');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `conversation_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `read_status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `conversation_id`, `sender_id`, `message`, `read_status`, `created_at`) VALUES
(1, 1, 1, 'hy', 1, '2024-04-22 05:37:13'),
(2, 1, 2, 'how are you? i am just checking is it work properly', 1, '2024-04-22 05:37:50'),
(3, 1, 2, 'hy', 0, '2024-04-22 15:36:38'),
(4, 1, 1, 'hy', 0, '2024-04-27 06:44:10');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `read_status` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `message`, `created_at`, `read_status`) VALUES
(1, 2, 'Syed Mansoor has accepted your friend request.', '2024-04-13 19:45:25', 1),
(2, 3, 'Syed Mansoor has accepted your friend request.', '2024-04-15 16:44:15', 1),
(3, 1, 'syed has accepted your friend request.', '2024-04-22 05:32:46', 1),
(4, 1, 'syed has accepted your friend request.', '2024-04-22 05:36:57', 1);

-- --------------------------------------------------------

--
-- Table structure for table `post_likes`
--

CREATE TABLE `post_likes` (
  `id` int(11) NOT NULL,
  `postId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `liked` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `post_likes`
--

INSERT INTO `post_likes` (`id`, `postId`, `userId`, `liked`) VALUES
(1, 1, 3, 1),
(2, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `bio` text DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `current_weight` int(11) DEFAULT NULL,
  `target_weight` int(11) DEFAULT NULL,
  `goal` varchar(50) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `profilePicture` varchar(255) DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `bio`, `country`, `city`, `current_weight`, `target_weight`, `goal`, `password`, `profilePicture`, `type`, `created_at`) VALUES
(1, 'Syed Mansoor', 'Hussain Shah', 'syedmansoor78900@gmail.com', 'blaa blaa', 'Pakistan', 'Kohat', 48, 98, 'Bulk,Maintain,Cut', '$2y$10$PuM2HHZzwMWyqdstmKaQk.XnBSfhMMtg3Qxmj5hfSgQ7r99roSrme', '2024-04-15_1713199720_1624240500_avatar.png', 0, '2024-04-13 16:42:52'),
(2, 'syed', 'mansoor', 'example@gmail.com', NULL, 'pakistan', 'kohat', 48, 45, 'Cut,Gain_Muscle', '$2y$10$e8dYbMTq4HgkQKqLvF1qWeV/XKfP36CA1d4iVkqCvsoE.1UCYbZhe', NULL, 0, '2024-04-13 16:43:58'),
(3, 'Syed Mansoor', 'Hussain Shah', 'syedmansoor00@gmail.com', '', 'Pakistan', 'Kohat', 48, 98, 'Bulk,Cut,Gain_Muscle', '$2y$10$JNMkJY8mu13RtcfZzoKvRuUNDz3Ltg31HNXTzeIn4nH1onvWA6acK', '2024-04-15_1713199815_avatar_660ed0b03d3822.69838063.png', 0, '2024-04-15 13:42:58'),
(4, 'super', 'admin', 'admin@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, '$2y$10$r25igcZoovUBFOGLnyx5Ie5qHMUCaTnhHSv/5tUu0wiCO81cjpl8a', NULL, 1, '2024-04-23 12:06:09'),
(6, 'Syed Mansoor', 'Hussain Shah', 'syedmansoor789123@gmail.com', NULL, 'Pakistan', 'Kohat', 34, 34, 'Cut', '$2y$10$zrJusMGjRBrNewzC5W.cf.ZxWkxYO59MdhpwvbTIm2sc7F2ZiRPGC', NULL, 1, '2024-04-27 15:31:16');

-- --------------------------------------------------------

--
-- Table structure for table `user_posts`
--

CREATE TABLE `user_posts` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `postText` text NOT NULL,
  `postImage` varchar(255) DEFAULT NULL,
  `isReport` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_posts`
--

INSERT INTO `user_posts` (`id`, `userId`, `postText`, `postImage`, `isReport`, `created_at`) VALUES
(1, 3, 'testing post', NULL, 0, '2024-04-15 16:47:20'),
(2, 1, 'checking', 'Screenshot (32).png', 0, '2024-04-17 00:11:24'),
(3, 1, 'this us test', NULL, 0, '2024-04-23 17:30:50'),
(4, 1, 'if he add a picture', 'evidance.png', 0, '2024-04-23 17:31:09'),
(5, 2, 'this is testing', NULL, 0, '2024-04-25 09:12:40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blockeduser`
--
ALTER TABLE `blockeduser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conversations`
--
ALTER TABLE `conversations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `diet_records`
--
ALTER TABLE `diet_records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `friend_requests`
--
ALTER TABLE `friend_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_posts`
--
ALTER TABLE `user_posts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blockeduser`
--
ALTER TABLE `blockeduser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `conversations`
--
ALTER TABLE `conversations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `diet_records`
--
ALTER TABLE `diet_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `friend_requests`
--
ALTER TABLE `friend_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `post_likes`
--
ALTER TABLE `post_likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_posts`
--
ALTER TABLE `user_posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `diet_records`
--
ALTER TABLE `diet_records`
  ADD CONSTRAINT `diet_records_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
