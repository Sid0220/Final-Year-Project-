<?php
include_once("./include/header.php");
?>

<input type="hidden" name="userIdCurrentOnline" id="userIdCurrentOnline" value="<?php echo $_SESSION['userId'] ?>">
<div class="row">
    <div class="col-lg-12">
        <div class="banner">
            <div class="banner_content" id="appendProfileImage">
               
            </div>
            <div class="banner_content_text">
                <p class="text-white banner_text" id="userName"></p>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="contact-container" id="appendUserInfo">

        </div>
    </div>
</div>
<div class="row text-center">
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12" id="date-viewer">
                    <button id="prev" class="btn btn-secondary">&#10094;</button>
                    <input type="date" id="date-input" style="display:none;">
                    <span id="today-date"></span>
                    <button id="next" class="btn btn-secondary">&#10095;</button>
                </div>
                <div class="col-12 mt-3">
                    <div class="accordion row m-0 p-2 bg-dark rounded-pill" data-section="breakfast">
                        <div class="col-6 col-sm-6 m-0 p-0 text-start text-white">
                            <button class="toggle-button btn btn-success rounded-pill d-none" data-target="#myModalBreakfast" data-section="breakfast">+</button>
                            <span>BREAKFAST</span>
                        </div>
                        <div class="col-6 col-sm-6 m-0 p-0 text-white">
                            <span class="kcal">0 (KCAL)</span>
                            <span class="protg">0.0 (PROTg)</span>
                        </div>
                    </div>
                    <div class="panel" data-section="breakfast">
                        <div class="row">
                            <div class="col-6 col-sm-6 m-0 pl-2 text-start ">
                                <span>No Data</span>
                            </div>
                            <div class="col-6 col-sm-6 m-0 p-0 ">
                                <span>0 (KCAL)</span>
                                <span>0.0 (PROTg)</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 mt-2">
                    <div class="accordion row m-0 p-2 bg-dark rounded-pill" data-section="lunch">
                        <div class="col-6 col-sm-6 m-0 p-0 text-start text-white">
                            <button class="toggle-button btn btn-success rounded-pill d-none" data-target="#myModalLunch" data-section="lunch">+</button>
                            <span>LUNCH</span>
                        </div>
                        <div class="col-6 col-sm-6 m-0 p-0 text-white">
                            <span class="kcal">0 (KCAL)</span>
                            <span class="protg">0.0 (PROTg)</span>
                        </div>
                    </div>
                    <div class="panel" data-section="lunch">
                        <div class="row">
                            <div class="col-6 col-sm-6 m-0 pl-2 text-start ">
                                <span>No Data</span>
                            </div>
                            <div class="col-6 col-sm-6 m-0 p-0 ">
                                <span>0 (KCAL)</span>
                                <span>0.0 (PROTg)</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 mt-2">
                    <div class="accordion row m-0 p-2 bg-dark rounded-pill" data-section="dinner">
                        <div class="col-6 col-sm-6 m-0 p-0 text-start text-white">
                            <button class="toggle-button btn btn-success rounded-pill d-none" data-target="#myModalLunch" data-section="dinner">+</button>
                            <span>DINNER</span>
                        </div>
                        <div class="col-6 col-sm-6 m-0 p-0 text-white">
                            <span class="kcal">0 (KCAL)</span>
                            <span class="protg">0.0 (PROTg)</span>
                        </div>
                    </div>
                    <div class="panel" data-section="dinner">
                        <div class="row">
                            <div class="col-6 col-sm-6 m-0 pl-2 text-start ">
                                <span>NO Data</span>
                            </div>
                            <div class="col-6 col-sm-6 m-0 p-0 ">
                                <span>0 (KCAL)</span>
                                <span>0.0 (PROTg)</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 mt-2">
                    <div class="accordion row m-0 p-2 bg-dark rounded-pill" data-section="snacks">
                        <div class="col-6 col-sm-6 m-0 p-0 text-start text-white">
                            <button class="toggle-button btn btn-success rounded-pill d-none" data-target="#myModalLunch" data-section="snacks">+</button>
                            <span>SNACKS</span>
                        </div>
                        <div class="col-6 col-sm-6 m-0 p-0 text-white">
                            <span class="kcal">0 (KCAL)</span>
                            <span class="protg">0.0 (PROTg)</span>
                        </div>
                    </div>
                    <div class="panel" data-section="snacks">
                        <div class="row">
                            <div class="col-6 col-sm-6 m-0 pl-2 text-start ">
                                <span>NO Data</span>
                            </div>
                            <div class="col-6 col-sm-6 m-0 p-0 ">
                                <span>0 (KCAL)</span>
                                <span>0.0 (PROTg)</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12" id="appendPost">
    </div>
</div>

</div>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Bootstrap Bundle JS (includes Popper) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- jQuery first -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="./../assets/js/lib/toastr.js"></script>
<script src="./../assets/js/userView/userProfile.js"></script>
<script src="./../assets/js/common.js"></script>
</body>

</html>