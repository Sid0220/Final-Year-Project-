<?php include_once("./include/header.php"); ?>

<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
<div class="row">
  <input type="hidden" name="current_user" id="current_user" value="<?php echo $_SESSION['userId']; ?>">
  <input type="hidden" name="current_conversation_id" id="current_conversation_id">
  <div class="col-md-4 bg-white ">
    <div class=" row border-bottom padding-sm backbtn btn-secondary" style="height: 40px;">
      Back
    </div>
    <ul class="friend-list" id="AppendFriendList">
    </ul>
  </div>
  <div class="col-md-8 bg-white chatarea">
    <div class="chat-message">
      <ul class="chat">


      </ul>
    </div>
    <div class="chat-box bg-white" id="displayTextArea">
      <div class="input-group">
        <input id="message_input" class="form-control border no-shadow no-rounded" placeholder="Type your message here">
        <span class="input-group-btn">
          <button class="btn btn-success no-rounded btn-send" type="button">Send</button>
        </span>
      </div>
    </div>
  </div>
  
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
<script src="./../assets/js/lib/jquery.min.js"></script>
<script src="./../assets/js/lib/toastr.js"></script>
<script src="./../assets/js/chatting/chatThroughAjax.js"></script>
<script src="./../assets/js/common.js"></script>
</body>

</html>