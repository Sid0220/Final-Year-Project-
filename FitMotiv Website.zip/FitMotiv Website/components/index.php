<?php
include_once("./include/header.php");
?>
<div class="row">
  <div class="col-lg-12">
    <div class="banner">
      <div class="banner_content" id="appendProfileImage">
      </div>
      <div class="banner_content_text">
        <p class="text-white banner_text"><?php echo $_SESSION['firstName'] . ' ' . $_SESSION['lastName']  ?></p>
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-lg-4 friendsRow">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Friends</h5>
        <div class="col-lg-12" id="AppendhereFriends">

        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-8">
    <form id="post">
      <input type="hidden" name="userId" id="userId_online" value="<?php echo $_SESSION['userId']; ?>">
      <div class="post-area">
        <textarea placeholder="What's on your mind?" class="post-textarea" id="postText" name="postText"></textarea>
        <div class="col-lg-12">
        <div class="row">
          <div class="col-lg-8">
            <span id="previewHere"></span>
          </div>
          <div class="col-lg-4">
            <label for="uploadPhoto" class="upload-photo-icon">
              <i class="fa fa-camera"></i> Upload Photo
            </label>
          </div>
        </div>
        </div>
        <input type="file" id="uploadPhoto" name="uploadPhoto" style="display: none;">
        <button class="post-button" type="submit">Post</button>
      </div>
    </form>
    <div class="row">
      <div class="col-lg-12" id="appendPost">
      </div>
    </div>
  </div>
</div>


</div>
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
<script src="./../assets/js/lib/jquery.min.js"></script>
<script src="./../assets/js/lib/toastr.js"></script>
<script src="./../assets/js/post/post.js"></script>
<script src="./../assets/js/common.js"></script>
</body>

</html>