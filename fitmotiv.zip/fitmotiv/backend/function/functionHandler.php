<?php
include_once("./../connection/connection.php");
session_start();
if (isset($_GET['action']) && $_GET['action'] == 'createPost') {
    $userId = $_POST['userId'];
    $postText = trim($_POST['postText']);

    if (strlen($postText) > 300) {
        echo json_encode(['error' => 'Your post cannot be over 300 characters.']);
        exit;
    }

    // Fetch user's first name
    $userQuery = $conn->prepare("SELECT firstname FROM users WHERE id = ?");
    $userQuery->bind_param("i", $userId);
    $userQuery->execute();
    $result = $userQuery->get_result();
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $firstName = $user['firstname'];
    } else {
        echo json_encode(['error' => 'User not found']);
        exit;
    }
    $userQuery->close();

    // Directory for user-specific images
    $targetDir = "./../../postImages/" . $firstName . "/";
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    $imageFileName = null;
    if (isset($_FILES['uploadPhoto']) && $_FILES['uploadPhoto']['error'] == 0) {
        $file = $_FILES['uploadPhoto'];
        $imageFileName = basename($file['name']);
        $targetFilePath = $targetDir . $imageFileName;
        if (!move_uploaded_file($file['tmp_name'], $targetFilePath)) {
            echo json_encode(['error' => 'Failed to upload image']);
            exit;
        }
    }
    $sql = "INSERT INTO `user_posts`(`userId`, `postText`, `postImage`, `created_at`) VALUES (?, ?, ?, NOW())";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        echo json_encode(['error' => 'Failed to prepare statement']);
        exit;
    }
    $stmt->bind_param("iss", $userId, $postText, $imageFileName);
    if ($stmt->execute()) {
        echo json_encode(['success' => 'Post created successfully']);
    } else {
        echo json_encode(['error' => 'Failed to create post']);
    }
    $stmt->close();
}
if (isset($_GET['action']) && $_GET['action'] == 'fetchPost') {
    $userId = $_SESSION['userId'];
    $blockQuery = "SELECT blockList FROM blockeduser WHERE userId = ?";
    $blockStmt = $conn->prepare($blockQuery);
    $blockStmt->bind_param("i", $userId);
    $blockStmt->execute();
    $blockResult = $blockStmt->get_result();
    $blockList = [];
    if ($blockRow = $blockResult->fetch_assoc()) {
        if ($decodedList = json_decode($blockRow['blockList'])) {
            $blockList = $decodedList;
        } else {
            $blockList = explode(',', $blockRow['blockList']);
        }
    }
    $blockStmt->close();
    $blockList = array_map('intval', $blockList);
    $blockListStr = implode(',', $blockList);
    $sql = "SELECT up.id AS postId, up.postText, up.postImage, up.created_at, u.id AS userId, u.firstName, u.lastName, u.profilePicture 
            FROM user_posts up 
            JOIN users u ON up.userId = u.id 
            WHERE up.isReport = ? AND u.id NOT IN ($blockListStr)
            ORDER BY up.created_at DESC";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        echo json_encode(['error' => 'Failed to prepare statement']);
        exit;
    }
    $isReported = 0; 
    $stmt->bind_param("i", $isReported);
    if ($stmt->execute()) {
        $result = $stmt->get_result();

        $posts = [];
        while ($post = $result->fetch_assoc()) {
            $commentsSql = "SELECT c.commentText, c.created_at, cu.firstName, cu.lastName, cu.profilePicture
                            FROM comments c
                            JOIN users cu ON c.userId = cu.id
                            WHERE c.postId = ? AND cu.id NOT IN ($blockListStr)
                            ORDER BY c.created_at DESC";
            $commentsStmt = $conn->prepare($commentsSql);
            $commentsStmt->bind_param("i", $post['postId']);
            $commentsStmt->execute();
            $commentsResult = $commentsStmt->get_result();

            $comments = [];
            while ($comment = $commentsResult->fetch_assoc()) {
                $comments[] = $comment;
            }
            $post['comments'] = $comments;

            $likesSql = "SELECT COUNT(*) AS likeCount FROM post_likes WHERE postId = ?";
            $likesStmt = $conn->prepare($likesSql);
            $likesStmt->bind_param("i", $post['postId']);
            $likesStmt->execute();
            $likesResult = $likesStmt->get_result();
            $like = $likesResult->fetch_assoc();
            $post['likeCount'] = $like['likeCount'];

            $posts[] = $post;

            $commentsStmt->close();
            $likesStmt->close();
        }

        echo json_encode($posts);
    } else {
        echo json_encode(['error' => 'Failed to fetch posts']);
    }
    $stmt->close();
    $conn->close();
}



if (isset($_GET['action']) && $_GET['action'] == 'addComment') {
    $userId = $_SESSION['userId'];
    $postId = $_POST['postId'];
    $commentText = $_POST['commentText'];
    $sql = "INSERT INTO comments (userId, postId, commentText) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        echo json_encode(['error' => 'Failed to prepare statement']);
        exit;
    }
    $stmt->bind_param("iis", $userId, $postId, $commentText);

    if ($stmt->execute()) {
        echo json_encode(['success' => 'Comment added successfully']);
    } else {
        echo json_encode(['error' => 'Failed to add comment']);
    }
    $stmt->close();
    $conn->close();
}
if (isset($_GET['action']) && $_GET['action'] == 'addLike') {
    $postId = $_POST['postId'];
    $userId = $_SESSION['userId'];
    $stmt = $conn->prepare("SELECT id FROM post_likes WHERE postId = ? AND userId = ?");
    $stmt->bind_param("ii", $postId, $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $deleteStmt = $conn->prepare("DELETE FROM post_likes WHERE postId = ? AND userId = ?");
        $deleteStmt->bind_param("ii", $postId, $userId);
        $deleteStmt->execute();
        $deleteStmt->close();

        echo json_encode(['message' => 'Like removed']);
    } else {
        $insertStmt = $conn->prepare("INSERT INTO post_likes (postId, userId) VALUES (?, ?)");
        $insertStmt->bind_param("ii", $postId, $userId);
        $insertStmt->execute();
        $insertStmt->close();

        echo json_encode(['message' => 'Like added']);
    }

    $stmt->close();
}

if (isset($_GET['action']) && $_GET['action'] == 'fetchLike') {
    $postId = $_POST['postId'];
    $currentUserId = isset($_SESSION['userId']) ? $_SESSION['userId'] : null;

    $sql = "SELECT * FROM `post_likes` WHERE `postId` = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        echo json_encode(['error' => 'Failed to prepare statement']);
        exit;
    }
    $stmt->bind_param("i", $postId);
    if ($stmt->execute()) {
        $result = $stmt->get_result();

        $likes = [];
        $userLiked = false;
        while ($like = $result->fetch_assoc()) {
            $likes[] = $like;
            if ($like['userId'] == $currentUserId) {
                $userLiked = true;
            }
        }
        echo json_encode(['count' => count($likes), 'likes' => $likes, 'userLiked' => $userLiked]);
    } else {
        echo json_encode(['error' => 'Failed to fetch likes']);
    }
    $stmt->close();
}
if (isset($_GET['action']) && $_GET['action'] == 'getDetailsOfUserProfile') {
    $userId = $_POST['user_id'];
    $query = "SELECT `id`, `firstName`, `lastName`,`bio`,`profilePicture`  FROM `users` WHERE `id` = ?";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        echo json_encode(['error' => 'Failed to prepare statement']);
        exit;
    }
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($user = $result->fetch_assoc()) {
        echo json_encode(['success' => true, 'user' => $user]);
    } else {
        echo json_encode(['success' => false, 'message' => 'User not found']);
    }
    $stmt->close();
}
if (isset($_GET['action']) && $_GET['action'] == 'fetchPostForASpecificUser') {
    $userId = $_POST['userId'];
    $isReport = 0;
    $sql = "SELECT up.id AS postId, up.postText,up.postImage, up.created_at, u.id AS userId, u.firstName, u.lastName, u.profilePicture 
    FROM user_posts up 
    JOIN users u ON up.userId = u.id 
    WHERE up.userId = ? AND `isReport` = ?
    ORDER BY up.created_at DESC";

    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        echo json_encode(['error' => 'Failed to prepare statement']);
        exit;
    }
    $stmt->bind_param("ii", $userId, $isReport);

    if ($stmt->execute()) {
        $result = $stmt->get_result();

        $posts = [];
        while ($post = $result->fetch_assoc()) {
            $commentsSql = "SELECT c.commentText, c.created_at, cu.firstName, cu.lastName, cu.profilePicture
                    FROM comments c
                    JOIN users cu ON c.userId = cu.id
                    WHERE c.postId = ?
                    ORDER BY c.created_at DESC";
            $commentsStmt = $conn->prepare($commentsSql);
            $commentsStmt->bind_param("i", $post['postId']);
            $commentsStmt->execute();
            $commentsResult = $commentsStmt->get_result();

            $comments = [];
            while ($comment = $commentsResult->fetch_assoc()) {
                $comments[] = $comment;
            }
            $post['comments'] = $comments;
            $likesSql = "SELECT COUNT(*) AS likeCount FROM post_likes WHERE postId = ?";
            $likesStmt = $conn->prepare($likesSql);
            $likesStmt->bind_param("i", $post['postId']);
            $likesStmt->execute();
            $likesResult = $likesStmt->get_result();
            $like = $likesResult->fetch_assoc();
            $post['likeCount'] = $like['likeCount'];

            $posts[] = $post;

            $commentsStmt->close();
            $likesStmt->close();
        }

        echo json_encode($posts);
    } else {
        echo json_encode(['error' => 'Failed to fetch posts']);
    }
    $stmt->close();
    $conn->close();
}
if (isset($_GET['action']) && $_GET['action'] == 'updateUserProfile') {
    $userId = $_SESSION['userId'];
    $bio = $_POST['bio'];
    $uploadDir = './../../uploads/';
    $fileName = '';
    $currentPicSql = "SELECT profilePicture FROM users WHERE id = ?";
    $currentPicStmt = $conn->prepare($currentPicSql);
    $currentPicStmt->bind_param('i', $userId);
    $currentPicStmt->execute();
    $result = $currentPicStmt->get_result();
    $user = $result->fetch_assoc();
    $currentFileName = $user['profilePicture'];
    if (isset($_FILES['profilePicture']) && $_FILES['profilePicture']['error'] === UPLOAD_ERR_OK) {
        if (!empty($currentFileName) && file_exists($uploadDir . $currentFileName)) {
            unlink($uploadDir . $currentFileName);
        }
        $file = $_FILES['profilePicture'];
        $date = date('Y-m-d');
        $timeStamp = time();
        $baseName = basename($file['name']);
        $fileName = "{$date}_{$timeStamp}_{$baseName}";
        $targetFilePath = $uploadDir . $fileName;
        if (!move_uploaded_file($file['tmp_name'], $targetFilePath)) {
            echo json_encode(['success' => false, 'message' => 'Failed to upload file.']);
            exit;
        }
    }
    try {
        if (!empty($fileName)) {
            $sql = "UPDATE users SET bio = ?, profilePicture = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('ssi', $bio,  $fileName, $userId);
        } else {
            $sql = "UPDATE users SET bio = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('si', $bio,  $userId);
        }
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Profile updated successfully.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update profile.']);
        }
        $stmt->close();
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
    $conn->close();
}
if (isset($_GET['action']) && $_GET['action'] == 'postPageDetails') {
    $userId = $_SESSION['userId'];
    $query = "SELECT `profilePicture`  FROM `users` WHERE `id` = ?";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        echo json_encode(['error' => 'Failed to prepare statement']);
        exit;
    }
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($user = $result->fetch_assoc()) {
        echo json_encode(['success' => true, 'user' => $user]);
    } else {
        echo json_encode(['success' => false, 'message' => 'User not found']);
    }
    $stmt->close();
}
if (isset($_GET['action']) && $_GET['action'] == 'ReportThePost') {
    $userId = $_POST['userId'];
    $postId = $_POST['postId'];
    $sql = "INSERT INTO post_reports (userId, postId) VALUES (?, ?)";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param('ii', $userId, $postId);
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Report submitted successfully.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to submit report.']);
        }
        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to prepare statement.']);
    }

    $conn->close();
}
if (isset($_GET['action']) && $_GET['action'] == 'reportUser') {
    $userId = $_POST['userId'];
    $sql = "INSERT INTO user_reports (userId) VALUES (?)";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        echo json_encode(['error' => 'Failed to prepare statement']);
        exit;
    }
    $stmt->bind_param('i', $userId);
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'User report submitted successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to submit user report.']);
    }
    $stmt->close();
    $conn->close();
}
if (isset($_GET['action']) && $_GET['action'] == 'getAllUser') {
    $userId = $_SESSION['userId'];

    // Fetch the user's goals
    $query = "SELECT goal FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        echo json_encode(['success' => false, 'message' => 'Database error in preparing the statement']);
        exit;
    }
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $userGoals = explode(',', $user['goal']); // Split goals into an array

        // Prepare a dynamic part of the query for goal matching
        $goalConditions = [];
        foreach ($userGoals as $goal) {
            $goal = trim($goal); // Clean up whitespace
            $goalConditions[] = "FIND_IN_SET('" . $conn->real_escape_string($goal) . "', u.goal)";
        }
        $goalConditionStr = implode(' OR ', $goalConditions);

        // Query to find users with matching goals but no direct friend request relation
        $query = "SELECT u.* FROM users u
                  WHERE u.id != ? AND NOT EXISTS (
                      SELECT 1 FROM friend_requests fr 
                      WHERE (fr.requester_id = ? AND fr.requestee_id = u.id) OR 
                            (fr.requestee_id = ? AND fr.requester_id = u.id)
                            AND fr.status IN ('pending', 'accepted')
                  ) AND ($goalConditionStr)";

        $stmt = $conn->prepare($query);
        if (!$stmt) {
            echo json_encode(['success' => false, 'message' => 'Database error in preparing the statement']);
            exit;
        }
        $stmt->bind_param("iii", $userId, $userId, $userId);
        $stmt->execute();
        $suggestionsResult = $stmt->get_result();

        $suggestions = [];
        while ($row = $suggestionsResult->fetch_assoc()) {
            $suggestions[] = $row;
        }

        if (!empty($suggestions)) {
            echo json_encode(['success' => true, 'suggestions' => $suggestions]);
        } else {
            echo json_encode(['success' => false, 'message' => 'No suggestions found based on shared goals.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'User goal not found or user does not exist.']);
    }

    $stmt->close();
    $conn->close();
}

if (isset($_POST['action']) && $_POST['action'] == 'sendFriendRequest') {
    $presentUser = $_SESSION['userId'];
    $requestTo = $_POST['requestTo'];
    $checkRequest = $conn->prepare("SELECT id FROM friend_requests WHERE requester_id = ? AND requestee_id = ?");
    $checkRequest->bind_param("ii", $presentUser, $requestTo);
    $checkRequest->execute();
    $result = $checkRequest->get_result();

    if ($result->num_rows > 0) {
        echo json_encode(['error' => 'Friend request already sent.']);
        exit;
    }
    $stmt = $conn->prepare("INSERT INTO friend_requests (requester_id, requestee_id, status) VALUES (?, ?, 'pending')");
    $stmt->bind_param("ii", $presentUser, $requestTo);

    if ($stmt->execute()) {
        echo json_encode(['success' => 'Friend request sent successfully.']);
    } else {
        echo json_encode(['error' => 'Failed to send friend request.']);
    }
}

if (isset($_GET['action']) && $_GET['action'] == 'fetchRequest') {
    $userId = $_SESSION['userId'];
    $query = "SELECT fr.id as request_id, fr.requester_id,  u.firstName as requester_firstname , u.lastName as requester_lastname, u.profilePicture as requester_picture
              FROM friend_requests fr
              JOIN users u ON u.id = fr.requester_id
              WHERE fr.requestee_id = ? AND fr.status = 'pending'";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    $requests = [];
    while ($row = $result->fetch_assoc()) {
        $requests[] = $row;
    }

    if (!empty($requests)) {
        echo json_encode(['success' => true, 'requests' => $requests]);
    } else {
        echo json_encode(['success' => false, 'message' => 'No friend requests found.']);
    }

    $stmt->close();
    $conn->close();
}
if (isset($_GET['action']) && $_GET['action'] == 'totalRequestCount') {
    $userId = $_SESSION['userId'];

    $query = "SELECT COUNT(*) as totalRequests FROM friend_requests WHERE requestee_id = ? AND status = 'pending'";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();

    if ($result->num_rows > 0) {
        echo json_encode(['success' => true, 'totalRequests' => $data['totalRequests']]);
    } else {
        echo json_encode(['success' => false, 'totalRequests' => 0, 'message' => 'No pending friend requests.']);
    }

    $stmt->close();
    $conn->close();
}
if (isset($_GET['action']) && $_GET['action'] == 'acceptRequest') {
    $userId = $_SESSION['userId'];
    $requestId = $_POST['requestId'];
    $userQuery = "SELECT firstName FROM users WHERE id = ?";
    $userStmt = $conn->prepare($userQuery);
    $userStmt->bind_param("i", $userId);
    $userStmt->execute();
    $userResult = $userStmt->get_result();
    $userName = '';
    if ($userRow = $userResult->fetch_assoc()) {
        $userName = $userRow['firstName'];
    }
    $userStmt->close();
    $checkQuery = "SELECT requester_id FROM friend_requests WHERE id = ? AND requestee_id = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("ii", $requestId, $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $requesterId = $row['requester_id'];
        $updateQuery = "UPDATE friend_requests SET status = 'accepted' WHERE id = ?";
        $updateStmt = $conn->prepare($updateQuery);
        $updateStmt->bind_param("i", $requestId);
        $updateStmt->execute();

        if ($updateStmt->affected_rows > 0) {
            $message = "$userName has accepted your friend request.";
            $insertNotification = "INSERT INTO notifications (user_id, message) VALUES (?, ?)";
            $notificationStmt = $conn->prepare($insertNotification);
            $notificationStmt->bind_param("is", $requesterId, $message);
            $notificationStmt->execute();
            $insertConversation = "INSERT INTO conversations (user1_id, user2_id) VALUES (?, ?)";
            $conversationStmt = $conn->prepare($insertConversation);
            $minUserId = min($userId, $requesterId);
            $maxUserId = max($userId, $requesterId);
            $conversationStmt->bind_param("ii", $minUserId, $maxUserId);
            $conversationStmt->execute();

            echo json_encode(['success' => true, 'message' => 'Friend request accepted successfully.']);
            $conversationStmt->close();
        } else {
            echo json_encode(['error' => true, 'message' => 'Failed to accept friend request.']);
        }
        $updateStmt->close();
        $notificationStmt->close();
    } else {
        echo json_encode(['error' => true, 'message' => 'No friend request found or you do not have permission to accept this request.']);
    }

    $stmt->close();
    $conn->close();
}
if (isset($_GET['action']) && $_GET['action'] == 'getNotificationCount') {
    $userId = $_SESSION['userId'];
    $is_read = 0;
    $query = "SELECT COUNT(*) as total FROM notifications WHERE user_id = ? AND read_status=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $userId, $is_read);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        echo json_encode(['success' => true, 'totalNotifications' => $row['total']]);
    } else {
        echo json_encode(['success' => false, 'message' => 'No notifications found.']);
    }

    $stmt->close();
    $conn->close();
}
if (isset($_GET['action']) && $_GET['action'] == 'getNotification') {
    $userId = $_SESSION['userId'];
    $query = "SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    $notifications = [];
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }

    if (!empty($notifications)) {
        echo json_encode(['success' => true, 'notifications' => $notifications]);
    } else {
        echo json_encode(['success' => false, 'message' => 'No notifications found.']);
    }

    $stmt->close();
    $conn->close();
}
if (isset($_GET['action']) && $_GET['action'] == 'updateReadStatus') {
    $notificationId = $_POST['notificationId'];
    $userId = $_SESSION['userId'];
    $query = "UPDATE notifications SET read_status = 1 WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $notificationId, $userId);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo json_encode(['success' => true, 'message' => 'Notification status updated.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update notification status or no permission.']);
    }

    $stmt->close();
    $conn->close();
}
if (isset($_GET['action']) && $_GET['action'] == 'fetchFriend') {
    $userId = $_SESSION['userId'];
    $query = "SELECT 
            c.id AS conversationId, 
            IF(c.user1_id = ?, c.user2_id, c.user1_id) AS friendId, 
            u.firstname AS firstfriendName, 
            u.lastname AS lastfriendName, 
            u.profilePicture AS friendPicture,
            m.message AS lastMessage, 
            m.created_at AS lastMessageTime,
            COALESCE(unread.count, 0) AS unreadCount
          FROM conversations c
          JOIN users u ON u.id = IF(c.user1_id = ?, c.user2_id, c.user1_id)
          LEFT JOIN messages m ON m.id = (
              SELECT MAX(id) FROM messages WHERE conversation_id = c.id
          )
          LEFT JOIN (
              SELECT conversation_id, COUNT(*) AS count
              FROM messages
              WHERE sender_id != ? AND read_status = 0
              GROUP BY conversation_id
          ) unread ON c.id = unread.conversation_id
          WHERE c.user1_id = ? OR c.user2_id = ?";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("iiiii", $userId, $userId, $userId, $userId, $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    $friends = [];
    while ($row = $result->fetch_assoc()) {
        $friends[] = $row;
    }

    if (!empty($friends)) {
        echo json_encode(['success' => true, 'friends' => $friends]);
    } else {
        echo json_encode(['success' => false, 'message' => 'No friends found.']);
    }

    $stmt->close();
    $conn->close();
}

if (isset($_GET['action']) && $_GET['action'] == 'fetchMessages') {
    $userId = $_SESSION['userId'];
    $conversationId = $_GET['conversationId'];

    // Check if the user is blocked or has blocked the other user
    $blockCheckQuery = "SELECT
                            (SELECT COUNT(*) FROM blockeduser WHERE userId = ? AND JSON_CONTAINS(blockList, JSON_QUOTE(CONVERT(u.id, CHAR)), '$')) as blockedByMe,
                            (SELECT COUNT(*) FROM blockeduser WHERE userId = u.id AND JSON_CONTAINS(blockList, JSON_QUOTE(CONVERT(?, CHAR)), '$')) as blockedMe,
                            IF(c.user1_id = ?, c.user2_id, c.user1_id) as otherUserId
                        FROM conversations c
                        JOIN users u ON u.id = IF(c.user1_id = ?, c.user2_id, c.user1_id)
                        WHERE c.id = ?";

    $blockStmt = $conn->prepare($blockCheckQuery);
    $blockStmt->bind_param("iiiii", $userId, $userId, $userId, $userId, $conversationId);
    $blockStmt->execute();
    $blockResult = $blockStmt->get_result()->fetch_assoc();
    $blockStmt->close();

    if ($blockResult['blockedByMe'] > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'You have blocked this user. Unblock to see messages.',
            'blocked' => true,
            'blockedUserId' => $blockResult['otherUserId']
        ]);
        exit;
    } elseif ($blockResult['blockedMe'] > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'You are blocked by this user.',
            'blocked' => false,
            'blockedUserId' => $blockResult['otherUserId']
        ]);
        exit;
    }
    $query = "SELECT m.id, m.message, m.created_at, m.sender_id, u.firstname, u.lastname, u.profilePicture 
              FROM messages m
              JOIN users u ON u.id = m.sender_id
              WHERE m.conversation_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $conversationId);
    $stmt->execute();
    $result = $stmt->get_result();
    $messages = [];
    while ($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }
    $stmt->close();

    echo json_encode(['success' => true, 'messages' => $messages]);
    $conn->close();
}

if (isset($_GET['action']) && $_GET['action'] == 'sendMessage') {
    $conversationId = $_POST['conversationId'];
    $message = $_POST['message'];
    $userId = $_SESSION['userId'];
    $conversationId = filter_var($conversationId, FILTER_SANITIZE_NUMBER_INT);
    $message = filter_var($message, FILTER_SANITIZE_STRING);

    if (!empty($message) && !empty($conversationId)) {
        $query = "INSERT INTO messages (conversation_id, sender_id, message) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($query);
        if ($stmt) {
            $stmt->bind_param("iis", $conversationId, $userId, $message);
            $stmt->execute();
            if ($stmt->affected_rows > 0) {
                echo json_encode(['success' => true, 'message' => 'Message sent successfully.']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to send message.']);
            }
            $stmt->close();
        } else {
            echo json_encode(['success' => false, 'message' => 'Database prepare error.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid input data.']);
    }
    $conn->close();
}



if (isset($_GET['action']) && $_GET['action'] == 'fetchAllFriends') {
    $userId = $_SESSION['userId'];

    $query = "SELECT u.id, u.firstname, u.lastname, u.profilePicture 
          FROM users u
          JOIN friend_requests fr ON (fr.requester_id = u.id OR fr.requestee_id = u.id)
          LEFT JOIN blockeduser bu1 ON bu1.userId = ? AND JSON_CONTAINS(bu1.blockList, JSON_QUOTE(CONVERT(u.id, CHAR)), '$')
          LEFT JOIN blockeduser bu2 ON bu2.userId = u.id AND JSON_CONTAINS(bu2.blockList, JSON_QUOTE(CONVERT(?, CHAR)), '$')
          WHERE (fr.requester_id = ? OR fr.requestee_id = ?)
            AND fr.status = 'accepted'
            AND u.id != ?
            AND bu1.userId IS NULL
            AND bu2.userId IS NULL";

    $stmt = $conn->prepare($query);
    if ($stmt) {
        $stmt->bind_param("iiiii", $userId, $userId, $userId, $userId, $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $friends = [];
        while ($row = $result->fetch_assoc()) {
            $friends[] = $row;
        }
        $stmt->close();
        echo json_encode(['success' => true, 'friends' => $friends]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Database query error']);
    }
}

if (isset($_GET['action']) && $_GET['action'] == 'delayFriendRequest') {
    $userId = $_SESSION['userId'];
    $requestId = $_POST['requestId'];
    $checkQuery = "SELECT requester_id FROM friend_requests WHERE id = ? AND requestee_id = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("ii", $requestId, $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $requesterId = $row['requester_id'];
        $updateQuery = "UPDATE friend_requests SET status = 'delayed' WHERE id = ?";
        $updateStmt = $conn->prepare($updateQuery);
        $updateStmt->bind_param("i", $requestId);
        $updateStmt->execute();

        if ($updateStmt->affected_rows > 0) {
            echo json_encode(['success' => true, 'message' => 'Friend request delayed successfully.']);
        } else {
            echo json_encode(['error' => true, 'message' => 'Failed to delay friend request.']);
        }
        $updateStmt->close();
    } else {
        echo json_encode(['error' => true, 'message' => 'No friend request found or you do not have permission to delay this request.']);
    }

    $stmt->close();
    $conn->close();
}
if (isset($_GET['action']) && $_GET['action'] == 'blockTheUser') {
    $userId = $_SESSION['userId'];
    $blockUserId = $_POST['userId'];
    $stmt = $conn->prepare("SELECT blockList FROM blockeduser WHERE userId = ?");
    if (!$stmt) {
        echo json_encode(['success' => false, 'message' => 'Failed to prepare the statement.']);
        exit;
    }
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $currentBlockList = json_decode($row['blockList'], true);
        if (!in_array($blockUserId, $currentBlockList)) {
            $currentBlockList[] = $blockUserId;
        }
        $newBlockListJson = json_encode($currentBlockList);
        $updateStmt = $conn->prepare("UPDATE blockeduser SET blockList = ? WHERE userId = ?");
        if (!$updateStmt) {
            echo json_encode(['success' => false, 'message' => 'Failed to prepare the update statement.']);
            exit;
        }
        $updateStmt->bind_param("si", $newBlockListJson, $userId);
        $updateStmt->execute();

        if ($updateStmt->affected_rows > 0) {
            echo json_encode(['success' => true, 'message' => 'User successfully blocked.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'No changes made. User already blocked.']);
        }
        $updateStmt->close();
    } else {
        $newBlockList = json_encode([$blockUserId]);
        $insertStmt = $conn->prepare("INSERT INTO blockeduser (userId, blockList) VALUES (?, ?)");
        if (!$insertStmt) {
            echo json_encode(['success' => false, 'message' => 'Failed to prepare the insert statement.']);
            exit;
        }
        $insertStmt->bind_param("is", $userId, $newBlockList);
        $insertStmt->execute();

        if ($insertStmt->affected_rows > 0) {
            echo json_encode(['success' => true, 'message' => 'User successfully blocked.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to block user.']);
        }
        $insertStmt->close();
    }
    $stmt->close();
    $conn->close();
}
if (isset($_GET['action']) && $_GET['action'] == 'unblockUser') {
    $userId = $_SESSION['userId'];
    $unblockUserId = $_POST['userId'];

    // Fetch the current block list
    $fetchBlockListQuery = "SELECT blockList FROM blockeduser WHERE userId = ?";
    $stmt = $conn->prepare($fetchBlockListQuery);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $blockData = $result->fetch_assoc();
    $stmt->close();

    if ($blockData) {
        $blockList = json_decode($blockData['blockList']);
        if (($key = array_search($unblockUserId, $blockList)) !== false) {
            unset($blockList[$key]);  // Remove user from block list
        }

        // Update the block list in the database
        $updatedBlockList = json_encode(array_values($blockList));  // Reindex array and encode to JSON
        $updateQuery = "UPDATE blockeduser SET blockList = ? WHERE userId = ?";
        $updateStmt = $conn->prepare($updateQuery);
        $updateStmt->bind_param("si", $updatedBlockList, $userId);
        $success = $updateStmt->execute();
        $updateStmt->close();

        if ($success) {
            echo json_encode(['success' => true, 'message' => 'User successfully unblocked']);
        } else {
            echo json_encode(['error' => true, 'message' => 'Failed to unblock user']);
        }
    } else {
        echo json_encode(['error' => true, 'message' => 'No block list found']);
    }
}
if (isset($_POST['action']) && $_POST['action'] == 'submitDiet') {
    if (!isset($_SESSION['userId'])) {
        echo json_encode(['status' => 'error', 'message' => 'User not logged in']);
        exit;
    }
    $userId = $_SESSION['userId'];
    $section = $_POST['section'];
    $date = $_POST['date'];
    $name = $_POST['name'];
    $kcal = $_POST['KCAL'];
    $protg = $_POST['PROTg'];
    if (empty($section) || empty($date) || empty($name) || empty($kcal) || empty($protg)) {
        echo json_encode(['status' => 'error', 'message' => 'Missing required fields']);
        exit;
    }
    $query = $conn->prepare("INSERT INTO diet_records (userId, section, date, name, KCAL, PROTg) VALUES (?, ?, ?, ?, ?, ?)");
    $query->bind_param("isssss", $userId, $section, $date, $name, $kcal, $protg);
    if ($query->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Data submitted successfully']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to submit data: ' . $query->error]);
    }
    $query->close();
}
if (isset($_GET['action']) && $_GET['action'] == 'fetchDietsOfUser') {
    if (!isset($_SESSION['userId'])) {
        echo json_encode(['status' => 'error', 'message' => 'User not logged in']);
        exit;
    }

    if (!isset($_POST['dataSelected'])) {
        echo json_encode(['status' => 'error', 'message' => 'No date provided']);
        exit;
    }

    $userId = $_SESSION['userId'];
    $dataSelected = $_POST['dataSelected']; 

    $query = $conn->prepare("SELECT section, date, name, KCAL, PROTg FROM diet_records WHERE userId = ? AND date = ?");
    $query->bind_param("is", $userId, $dataSelected); 

    if ($query->execute()) {
        $result = $query->get_result();
        $diets = $result->fetch_all(MYSQLI_ASSOC);

        if ($diets) {
            echo json_encode(['status' => 'success', 'data' => $diets]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'No diets found for this user on the selected date']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Query failed: ' . $query->error]);
    }

    $query->close();
}
if (isset($_GET['action']) && $_GET['action'] == 'fetchDietsOfUserSpecific') {
    if (!isset($_POST['userId'])) {
        echo json_encode(['status' => 'error', 'message' => 'User not logged in']);
        exit;
    }

    if (!isset($_POST['dataSelected'])) {
        echo json_encode(['status' => 'error', 'message' => 'No date provided']);
        exit;
    }

    $userId = $_POST['userId'];
    $dataSelected = $_POST['dataSelected']; 

    $query = $conn->prepare("SELECT section, date, name, KCAL, PROTg FROM diet_records WHERE userId = ? AND date = ?");
    $query->bind_param("is", $userId, $dataSelected); 

    if ($query->execute()) {
        $result = $query->get_result();
        $diets = $result->fetch_all(MYSQLI_ASSOC);

        if ($diets) {
            echo json_encode(['status' => 'success', 'data' => $diets]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'No diets found for this user on the selected date']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Query failed: ' . $query->error]);
    }

    $query->close();
}