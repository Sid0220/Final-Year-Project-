<?php
include_once("./../connection/connection.php");
if (isset($_GET['action']) && $_GET['action'] == 'fetchUser') {
    $sql = "SELECT `id`, `firstname`, `lastname`, `email`, `bio`, `country`, `city`, `current_weight`, `target_weight`, `goal` FROM `users` WHERE `type` = 0";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        echo json_encode(['success' => false, 'message' => 'Database prepare error']);
        exit;
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $users = [];
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }

    $stmt->close();
    if (count($users) > 0) {
        echo json_encode(['success' => true, 'users' => $users]);
    } else {
        echo json_encode(['success' => false, 'message' => 'No users found.']);
    }
}
if(isset($_POST['action']) && $_POST['action'] == 'deleteUser') {
    if(isset($_POST['userId']) && !empty($_POST['userId'])) {
        $userId = mysqli_real_escape_string($conn, $_POST['userId']);
        $query = "DELETE FROM users WHERE id = '$userId'";

        if(mysqli_query($conn, $query)) {
            if(mysqli_affected_rows($conn) > 0) {
                $response = array('success' => true, 'message' => 'User deleted successfully.');
            } else {
                $response = array('success' => false, 'message' => 'No user found with the provided ID.');
            }
        } else {
            $response = array('success' => false, 'message' => 'Failed to delete user: ' . mysqli_error($conn));
        }
    } else {
        $response = array('success' => false, 'message' => 'User ID is missing or invalid.');
    }

    echo json_encode($response);
}
?>