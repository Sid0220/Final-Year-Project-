<!doctype html>
<html lang="en">
<head>
    <title>FITMOTIV</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="./assets/css/lib/bootstrap4.css" rel="stylesheet" />
    <link href="./assets/css/lib/toastr.css" rel="stylesheet" />
    <link rel="stylesheet" href="./assets/css/style.css">
</head>
<body>
    <div class="container-fluid login-bg vh-100 d-flex align-items-center justify-content-center">
        <div class="row w-100">
            <div class="col-md-4 col-12 mx-auto">
                <div class="card custom_card">
                    <div class="card-body">
                        <h5 class="card-title">Login</h5>
                        <form id="login_form">
                            <div class="form-group">
                                <label for="loginEmail" class="loginEmail">Email</label>
                                <input type="text" class="form-control" name="loginEmail" id="loginEmail" placeholder="Enter Your Email" required>
                            </div>
                            <div class="form-group">
                                <label for="loginPassword" class="loginPassword">Password</label>
                                <input type="password" class="form-control" name="loginPassword" id="loginPassword" placeholder="**********" required>
                            </div>
                            <button type="submit" class="btn btn-secondary">Login</button>
                            <p>No account? Click <a href="./signup.php" class="text-white">here</a></p>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="./assets/js/lib/jquery.min.js"></script>
    <script src="./assets/js/lib/toastr.js"></script>
    <script src="./assets/js/lib/bootstrap4.js"></script>
    <script src="./assets/js/auth/auth.js"></script>
</body>
</html>
