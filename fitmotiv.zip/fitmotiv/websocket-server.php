<?php

use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;
use MyApp\Chat;

require  './vendor/autoload.php';
require  './src/Chat.php';
include_once("./backend/connection/connection.php");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new Chat($conn)
        )
    ),
    8080
);
$server->run();

?>
