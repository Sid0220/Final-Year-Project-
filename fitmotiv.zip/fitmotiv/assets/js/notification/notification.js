function fetchNotificationsCount(){
    $.ajax({
        url: './../backend/function/functionHandler.php?action=getNotificationCount',
        method: 'GET',
        dataType: 'json',
        success: function (data) {
            console.log(data);
            if (data.success) {
                $("#appendNumberNotification").text(data.totalNotifications);
            }
        }
    })
}
function fetchNotificationTotal() {
    $.ajax({
        url: './../backend/function/functionHandler.php?action=getNotification',
        method: 'GET',
        dataType: 'json',
        success: function(data) {
            console.log(data);
            if (data.success) {
                $("#getNotifiation").empty(); 
                data.notifications.forEach(function(notification) {
                    var cardClass = notification.read_status == 1 ? "custom_card text-white" : "";
                    $("#getNotifiation").append(`<div class="card ${cardClass} mt-2 mb-2" data-id="${notification.id}">
                        <div class="card-body d-flex justify-content-between align-items-center">
                            <p class="card-text">${notification.message}</p>
                            <p>${notification.created_at}</p>
                        </div>
                    </div>`);
                });
            }
        }
    });
}

function updateReadStatus(notificationId) {
    $.ajax({
        url: './../backend/function/functionHandler.php?action=updateReadStatus',
        method: 'POST',
        dataType: 'json',
        data: { notificationId: notificationId },
        success: function(data) {
            if (data.success) {
                fetchNotificationsCount();
                fetchNotificationTotal(); 
            }
        }
    });
}

$(document).ready(function() {
    fetchNotificationTotal();
    $("#getNotifiation").on('click', '.card-body', function() {
        var notificationId = $(this).closest('.card').data('id'); 
        updateReadStatus(notificationId);
    });
});
