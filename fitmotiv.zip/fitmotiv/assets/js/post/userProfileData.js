function addLikes(postId) {
    $.ajax({
        url: './../backend/function/functionHandler.php?action=fetchLike',
        method: "POST",
        dataType: "json",
        data: { postId: postId },
        success: function (data) {
            if (data.userLiked) {
                $(`.like-btn[data-post-id='${postId}']`).addClass('liked');
            }
            $(`.like-count[data-post-id='${postId}']`).text(data.count);
        }
    });
}


function fetchDiet() {
    var date = $('#date-input').val();
    console.log(date);
    $.ajax({
        url: "./../backend/function/functionHandler.php?action=fetchDietsOfUser",
        method: "POST",
        data: { dataSelected: date },
        dataType: 'json',
        success: function (response) {
            if (response.status === "success") {
                var breakfast = $('.accordion[data-section="breakfast"]');
                breakfast.find('.col-6.col-sm-6.m-0.p-0 span').eq(1).text( '0 KCAL');
                breakfast.find('.col-6.col-sm-6.m-0.p-0 span').eq(2).text('0 PROTg');
                var panelbreakfast = $('.panel[data-section="breakfast"]');
                var detailsHtmlbreakfast = '';
                detailsHtmlbreakfast += '<div class="row">' +
                '<div class="col-6 col-sm-6 m-0 pl-2 text-start">  <span>No Data</span></div>' +
                '<div class="col-6 col-sm-6 m-0 p-0"> <span class="pe-2">0</span>' +
                '<span>0</span></div>' +
                '</div>';
                panelbreakfast.html(detailsHtmlbreakfast);

                var lunch = $('.accordion[data-section="lunch"]');
                lunch.find('.col-6.col-sm-6.m-0.p-0 span').eq(1).text( '0 KCAL');
                lunch.find('.col-6.col-sm-6.m-0.p-0 span').eq(2).text('0 PROTg');
                var panellunch = $('.panel[data-section="lunch"]');
                var detailsHtmllunch = '';
                detailsHtmllunch += '<div class="row">' +
                '<div class="col-6 col-sm-6 m-0 pl-2 text-start">  <span>No Data</span></div>' +
                '<div class="col-6 col-sm-6 m-0 p-0"> <span class="pe-2">0</span>' +
                '<span>0</span></div>' +
                '</div>';
                panellunch.html(detailsHtmllunch);

                var dinner = $('.accordion[data-section="dinner"]');
                dinner.find('.col-6.col-sm-6.m-0.p-0 span').eq(1).text( '0 KCAL');
                dinner.find('.col-6.col-sm-6.m-0.p-0 span').eq(2).text('0 PROTg');
                var paneldinner = $('.panel[data-section="dinner"]');
                var detailsHtmldinner = '';
                detailsHtmldinner += '<div class="row">' +
                '<div class="col-6 col-sm-6 m-0 pl-2 text-start">  <span>No Data</span></div>' +
                '<div class="col-6 col-sm-6 m-0 p-0"> <span class="pe-2">0</span>' +
                '<span>0</span></div>' +
                '</div>';
                paneldinner.html(detailsHtmldinner);

                var snacks = $('.accordion[data-section="snacks"]');
                snacks.find('.col-6.col-sm-6.m-0.p-0 span').eq(1).text( '0 KCAL');
                snacks.find('.col-6.col-sm-6.m-0.p-0 span').eq(2).text('0 PROTg');
                var panelsnacks = $('.panel[data-section="snacks"]');
                var detailsHtmlsnacks = '';
                detailsHtmlsnacks += '<div class="row">' +
                '<div class="col-6 col-sm-6 m-0 pl-2 text-start">  <span>No Data</span></div>' +
                '<div class="col-6 col-sm-6 m-0 p-0"> <span class="pe-2">0</span>' +
                '<span>0</span></div>' +
                '</div>';
                panelsnacks.html(detailsHtmlsnacks);
                var totals = {};
                response.data.forEach(function (item) {
                    if (!totals[item.section]) {
                        totals[item.section] = { KCAL: 0, PROTg: 0, details: [] };
                    }
                    totals[item.section].KCAL += parseFloat(item.KCAL);
                    totals[item.section].PROTg += parseFloat(item.PROTg);
                    totals[item.section].details.push(item); 
                });
                Object.keys(totals).forEach(function (section) {
                    var accordion = $('.accordion[data-section="' + section + '"]');
                    var panel = $('.panel[data-section="' + section + '"]');
                    if (accordion.length) {
                        accordion.find('.col-6.col-sm-6.m-0.p-0 span').eq(1).text(totals[section].KCAL.toFixed(2) + ' KCAL');
                        accordion.find('.col-6.col-sm-6.m-0.p-0 span').eq(2).text(totals[section].PROTg.toFixed(2) + ' PROTg');
                    }
                    if (panel.length) {
                        var detailsHtml = '';
                        totals[section].details.forEach(function (detail) {
                            detailsHtml += '<div class="row">' +
                                '<div class="col-6 col-sm-6 m-0 pl-2 text-start">  <span>' + detail.name + '</span></div>' +
                                '<div class="col-6 col-sm-6 m-0 p-0"> <span class="pe-2">' + detail.KCAL + '</span>' +
                                '<span>' + detail.PROTg + '</span></div>' +
                                '</div>';
                        });
                        panel.html(detailsHtml);
                    }
                });
            } else {
                var breakfast = $('.accordion[data-section="breakfast"]');
                breakfast.find('.col-6.col-sm-6.m-0.p-0 span').eq(1).text( '0 KCAL');
                breakfast.find('.col-6.col-sm-6.m-0.p-0 span').eq(2).text('0 PROTg');
                var panelbreakfast = $('.panel[data-section="breakfast"]');
                var detailsHtmlbreakfast = '';
                detailsHtmlbreakfast += '<div class="row">' +
                '<div class="col-6 col-sm-6 m-0 pl-2 text-start">  <span>No Data</span></div>' +
                '<div class="col-6 col-sm-6 m-0 p-0"> <span class="pe-2">0</span>' +
                '<span>0</span></div>' +
                '</div>';
                panelbreakfast.html(detailsHtmlbreakfast);

                var lunch = $('.accordion[data-section="lunch"]');
                lunch.find('.col-6.col-sm-6.m-0.p-0 span').eq(1).text( '0 KCAL');
                lunch.find('.col-6.col-sm-6.m-0.p-0 span').eq(2).text('0 PROTg');
                var panellunch = $('.panel[data-section="lunch"]');
                var detailsHtmllunch = '';
                detailsHtmllunch += '<div class="row">' +
                '<div class="col-6 col-sm-6 m-0 pl-2 text-start">  <span>No Data</span></div>' +
                '<div class="col-6 col-sm-6 m-0 p-0"> <span class="pe-2">0</span>' +
                '<span>0</span></div>' +
                '</div>';
                panellunch.html(detailsHtmllunch);

                var dinner = $('.accordion[data-section="dinner"]');
                dinner.find('.col-6.col-sm-6.m-0.p-0 span').eq(1).text( '0 KCAL');
                dinner.find('.col-6.col-sm-6.m-0.p-0 span').eq(2).text('0 PROTg');
                var paneldinner = $('.panel[data-section="dinner"]');
                var detailsHtmldinner = '';
                detailsHtmldinner += '<div class="row">' +
                '<div class="col-6 col-sm-6 m-0 pl-2 text-start">  <span>No Data</span></div>' +
                '<div class="col-6 col-sm-6 m-0 p-0"> <span class="pe-2">0</span>' +
                '<span>0</span></div>' +
                '</div>';
                paneldinner.html(detailsHtmldinner);

                var snacks = $('.accordion[data-section="snacks"]');
                snacks.find('.col-6.col-sm-6.m-0.p-0 span').eq(1).text( '0 KCAL');
                snacks.find('.col-6.col-sm-6.m-0.p-0 span').eq(2).text('0 PROTg');
                var panelsnacks = $('.panel[data-section="snacks"]');
                var detailsHtmlsnacks = '';
                detailsHtmlsnacks += '<div class="row">' +
                '<div class="col-6 col-sm-6 m-0 pl-2 text-start">  <span>No Data</span></div>' +
                '<div class="col-6 col-sm-6 m-0 p-0"> <span class="pe-2">0</span>' +
                '<span>0</span></div>' +
                '</div>';
                panelsnacks.html(detailsHtmlsnacks);
            }
        },
        error: function (xhr, status, error) {
            console.error('Error fetching diets:', error);
        }
    });
}

$(document).ready(function () {
    var userId = $("#getUserId").val();
    function userInfo() {
        $.ajax({
            url: './../backend/function/functionHandler.php?action=getDetailsOfUserProfile',
            method: 'POST',
            data: { user_id: userId },
            dataType: 'json',
            success: function (data) {
                $("#appendProfileImage").html(` <img src="./../uploads/${data.user.profilePicture || './../assets/img/profile.png'}" alt="img profile" class="img img-fluid img_custom_banner">`);
                $("#navbarDropdownMenuLink").html(`<img src="./../uploads/${data.user.profilePicture || './../assets/img/profile.png'}" alt="profile image" class="img img-fluid img_custom rounded-circle" style="width: 40px; height: 40px;">`);
                $("#userName").html(`${data.user.firstName} ${data.user.lastName}`);
                $("#appendUserInfo").html(`
             <div class="d-flex justify-content-between align-items-center">
                    <h2 class="contact-header">${data.user.firstName} ${data.user.lastName}</h2>
                    <button class="btn btn-info" data-bs-toggle="modal" data-bs-target="#editProfileModal">Edit Profile</button>
             </div>
                <p class="contact-text">
                     ${data.user.bio || 'No Bio Yet.....'}
                </p>
             `);
                $("#bioTextarea").val(data.user.bio || '');
                $("#profilePicture").attr("src", data.user.profilePicture ? "./../uploads/" + data.user.profilePicture : './../assets/img/profile.png');
            }
        });
    }
    userInfo();
    function fetch() {

        $.ajax({
            url: './../backend/function/functionHandler.php?action=fetchPostForASpecificUser',
            method: "POST",
            dataType: "json",
            data: { userId: userId },
            success: function (data) {
                $("#appendPost").empty();
                data.forEach(function (post) {
                    var postHtml = `
                    <div class="post-container">
                    <div class="d-flex"  id="GetProfile" data-userid="${post.userId}">
                        <div class="post-image">
                            <img src="./../uploads/${post.profilePicture || './../assets/img/profile.png'}" alt="User Image" />
                        </div>
                        <div class="post-content ms-3">
                            <h3 class="user-name">${post.firstName} ${post.lastName}</h3>
                            <p>${post.postText}</p>
                            ${post.postImage ? `<img src="./../postImages/${post.firstName}/${post.postImage}" alt="Post Image" style="max-width: 100%; height: auto;">` : ''}
                        </div>
                        </div>
                            <div class="post-actions">
                                <button type="button" class="like-btn" data-post-id="${post.postId}" data-user-id="${post.userId}">Like</button> <span class="like-count">${post.likeCount || 0}</span>
                                <button type="button" class="comment-btn">Comment</button> <span class="comment-count">${post.comments.length || 0}</span>
                            </div>
                            <div class="comments-container col-lg-12" style="display: none;">`;

                    post.comments.forEach(function (comment) {
                        postHtml += `
                            <div class="existing-comment">
                                <p><strong>${comment.firstName} ${comment.lastName}:</strong> ${comment.commentText}</p>
                            </div>`;
                    });

                    postHtml += `
                                <!-- Add a new comment -->
                                <textarea class="comment-textarea" placeholder="Write a comment..."></textarea>
                                <button class="submit-comment" data-post-id="${post.postId}" data-user-id="${post.userId}">Submit</button>
                            </div>
                        </div>
                    </div>`;

                    $("#appendPost").append(postHtml);
                });
                $('.like-btn').each(function () {
                    var postId = $(this).data('post-id');
                    addLikes(postId);
                });
            }
        });
    }

    $(document).on('click', '.comment-btn', function () {
        $(this).closest('.post-container').find('.comments-container').slideToggle();
    });
    $(document).on('click', '.like-btn', function () {
        var $this = $(this);
        var postId = $this.data('post-id');
        var userId = $this.data('user-id');
        $.ajax({
            url: './../backend/function/functionHandler.php?action=addLike',
            method: "POST",
            data: { postId: postId, userId: userId },
            success: function (response) {
                var data = JSON.parse(response);
                if (data.message === 'Like added') {
                    $this.addClass('liked');
                    $this.find('.like-count').html(data.likeCount);
                } else if (data.message === 'Like removed') {
                    $this.removeClass('liked');
                }
                fetch();
            }
        });
    });

    $(document).on('click', '.submit-comment', function () {
        var commentText = $(this).prev('.comment-textarea').val();
        var postId = $(this).data('post-id');
        var userId = $(this).data('user-id');
        $.ajax({
            url: './../backend/function/functionHandler.php?action=addComment',
            method: "POST",
            data: { userId: userId, postId: postId, commentText: commentText },
            success: function (response) {
                fetch();
                var newCommentHtml = `<p><strong>You:</strong> ${commentText}</p>`;
                $(this).closest('.comments-container').find('.existing-comments').append(newCommentHtml);
            }
        });
    });
    fetch();
    $(document).on('click', '#GetProfile', function (e) {
        e.preventDefault();
        var userId = $(this).data('userid');
        window.location.href = "./userProfile.php?userId=" + userId;
    });
    $("#editPictureButton").click(function (e) {
        e.preventDefault();
        $("#profilePictureInput").click();
    });

    $("#profilePictureInput").change(function () {
        if (this.files && this.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#profilePicture').attr('src', e.target.result);
            }

            reader.readAsDataURL(this.files[0]);
        }
    });
    $('#editProfileForm').on('submit', function (e) {
        e.preventDefault();
        var formData = new FormData(this);

        $.ajax({
            url: './../backend/function/functionHandler.php?action=updateUserProfile',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                var data = JSON.parse(response);
                if (data.success) {
                    toastr.success(data.message);
                } else {
                    toastr.error(data.message);
                }
                $('#editProfileModal').modal('hide');
                userInfo();
                fetch();
            },
            error: function (xhr, status, error) {
                toastr.error('An error occurred: ' + error);
            }
        });
    });
    var currentDate = new Date();
    function updateDisplayedDate() {
        var dateElement = $('#today-date');
        var dateInput = $('#date-input');
        // Display date in local time zone
        dateElement.text(currentDate.toLocaleDateString());
        // Adjust the input value to consider the timezone offset
        dateInput.val(formatDateAsLocalISOString(currentDate));
        dateElement.css('cursor', 'pointer');
        $(this).hide();
        fetchDiet(); 
        dateElement.off('click').on('click', function () {
            dateInput.show().focus();
        });

        dateInput.off('change').on('change', function () {
            currentDate = new Date(this.value + 'T00:00'); // Set time to midday to avoid DST issues
            updateDisplayedDate();
            $(this).hide();
            fetchDiet(); 
        });
    }

    $('#prev').off('click').on('click', function () {
        currentDate.setDate(currentDate.getDate() - 1);
        updateDisplayedDate();
    });

    $('#next').off('click').on('click', function () {
        currentDate.setDate(currentDate.getDate() + 1);
        updateDisplayedDate();
    });

    // Helper function to format date as local ISO string
    function formatDateAsLocalISOString(date) {
        var offset = date.getTimezoneOffset() * 60000; // offset in milliseconds
        var localISOTime = (new Date(date - offset)).toISOString().slice(0, 10);
        return localISOTime;
    }

    updateDisplayedDate();
    $(".toggle-button").on('click', function () {
        var section = $(this).data('section');
        $("#section").val(section);
        var modal = $('#myModal');
        var title = section.charAt(0).toUpperCase() + section.slice(1);
        modal.find('.modal-title').text(title + ' Details');
        $("#date").val($('#date-input').val());
        modal.modal('show');
    });


    $('.accordion').click(function (event) {
        var section = $(this).find('.toggle-button').data('section');
        var panel = $('.panel[data-section="' + section + '"]');
        if (!$(event.target).hasClass('toggle-button')) {
            panel.toggleClass('active');
            if (panel.hasClass('active')) {
                panel.css('max-height', '40px').css('overflow-y', 'auto').fadeIn();
            } else {
                panel.css('max-height', 0).css('overflow-y', 'hidden').fadeOut();
            }
        }
    });

    $('.panel').click(function (event) {
        event.stopPropagation();
    });
    $('#dietSubmit').on('submit', function (e) {
        e.preventDefault();

        var formData = {
            section: $("#section").val(),
            date: $('#date').val(),
            name: $('#name').val(),
            KCAL: $('#KCAL').val(),
            PROTg: $('#PROTg').val(),
            action: 'submitDiet'
        };

        $.ajax({
            type: 'POST',
            url: './../backend/function/functionHandler.php',
            data: formData,
            dataType: 'json',
            success: function (response) {
                toastr.success('Data submitted successfully');
                fetchDiet();
            },
            error: function (xhr, status, error) {
                toastr.error('Error submitting data: ' + xhr.responseText);
            }
        });
    });

});
