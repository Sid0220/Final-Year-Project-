function fetchFriends(){
    $.ajax({
        url: "./../backend/function/functionHandler.php?action=fetchAllFriends",
        type: "GET",
        dataType: "json",
        success: function (data) {
            if (data.success && data.friends.length > 0) {
                $("#friends").empty();
                data.friends.forEach(function (friend) {
                    var friendImage = friend.profilePicture ? './../uploads/' + friend.profilePicture : './../assets/img/profile.png';
                    var friendCard = `<div class="col-lg-4"><div class="card custom_card mt-2 mb-2">
                        
                        <div class="card-body">
                            <div class="row">
                                <div class="col-4">
                                    <img class="card-img-top" src="${friendImage}" alt="Profile Image" style="width:auto;height:auto">
                                </div>
                               
                            <div class="col-8">
                            <h5 class="card-title text-center text-white">${friend.firstname} ${friend.lastname}</h5>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <button type="button" class="btn btn-info" onclick="window.location.href='userProfile.php?userId=${friend.id}'">View Profile</button>
                                        <button type="button" class="btn btn-secondary" onclick="window.location.href='./message.php'">Message</button>
                                    </div>
                                </div>
                                <div class="col-6 mt-2 text-center">
                                    <button type="button" class="btn btn-danger btn-block" data-friendId="${friend.id}">Block User</button>
                                </div>
                            </div>
                        </div>
                    </div></div>`;
                    $("#friends").append(friendCard);
                });
            } else {
                $("#friends").html('<p>No friends found.</p>');
            }
        },
        error: function (xhr, status, error) {
            console.error('Error fetching friends:', error);
            $("#friends").html('<p>Error fetching friends.</p>');
        }
    });
}
$(document).ready(function () {
   fetchFriends();
    $(document).on('click','.btn-block',function(){
        var id = $(this).data('friendid');
        $.ajax({
            url:'./../backend/function/functionHandler.php?action=blockTheUser',
            method: 'POST',
            data:{userId:id},
            dataType: 'json',
            success:function(data){
                if(data.success){
                    fetchFriends();
                }
            }
        })
    })
});
