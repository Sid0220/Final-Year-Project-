function fetchFriend() {
    $.ajax({
        url: './../backend/function/functionHandler.php?action=getAllUser',
        dataType: 'json',
        success: function (data) {
            $('#AppendhereFriends').empty();
            if (data.success && data.suggestions.length > 0) {
                $('#AppendhereFriends').empty();
                data.suggestions.forEach(function (user) {
                    console.log(user);
                    var profilePicture = user.profilePicture ? './../uploads/' + user.profilePicture : './../assets/img/profile.png';
                    var badgeHtml = `<span class="badge badge-success">${user.goal}</span>`;
                    $('#AppendhereFriends').append(
                        `<div class="d-flex align-items-center mb-3"  >
                            <img src="${profilePicture}" alt="" class="img img-fluid w-25 mr-2" id="goTOprofile" data-userid="${user.id}">
                            <div class="user-info">
                                <h5 class="user-name">${user.firstname} ${user.lastname}</h5>
                                ${badgeHtml} 
                            </div>
                            <button type="button" class="btn btn-secondary ml-auto" id="addFriendBtn" data-userid="${user.id}">
                                <i class="fas fa-user-plus"></i> 
                            </button>
                        </div>`
                    );
                });
            } else {
                $('#AppendhereFriends').append('<p>No users found.</p>');
            }
        },
        error: function (xhr, status, error) {
            console.error('Error fetching user data:', error);
            $('#AppendhereFriends').append('<p>Error fetching user data.</p>');
        }
    });
}
$(document).ready(function(){
    fetchFriend();
    $(document).on('click', '#addFriendBtn', function (e) {
        var userid = $(this).data('userid');
        $.ajax({
            url: "./../backend/function/functionHandler.php",
            method: "POST",
            data: { action: "sendFriendRequest", requestTo: userid },
            dataType: "json",
            success: function (data) {
                if (data.success) {
                    toastr.success(data.success);
                    fetchFriend();
                } else if (data.error) {
                    toastr.error(data.error);
                }
            },
            error: function (xhr, status, error) {
                toastr.error('Failed to send friend request. Please try again.');
            }
        })
    })
})