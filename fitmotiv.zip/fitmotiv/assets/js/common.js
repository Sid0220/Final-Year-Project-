function getProfile() {
    $.ajax({
        url: "./../backend/function/functionHandler.php?action=postPageDetails",
        method: "POST",
        dataType: "json",
        success: function (data) {
            $("#navbarDropdownMenuLink").html(`<img src="./../uploads/${data.user.profilePicture || './../assets/img/profile.png'}" alt="profile image" class="img img-fluid img_custom rounded-circle" style="width: 40px; height: 40px;">`);
        }
    })
}
function fetchRequest(){
    $.ajax({
        url: './../backend/function/functionHandler.php?action=totalRequestCount',
        method: 'GET',
        dataType: 'json',
        success: function (data) {
            if (data.success) {
                $("#appendNumberRequest").text(data.totalRequests);
            }
        }
    })
}
function fetchNotificationsCount(){
    $.ajax({
        url: './../backend/function/functionHandler.php?action=getNotificationCount',
        method: 'GET',
        dataType: 'json',
        success: function (data) {
            if (data.success) {
                $("#appendNumberNotification").text(data.totalNotifications);
            }
        }
    })
}
$(document).ready(function () {
    getProfile();
    fetchRequest();
    fetchNotificationsCount();
});