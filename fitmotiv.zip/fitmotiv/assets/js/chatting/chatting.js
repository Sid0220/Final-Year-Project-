var conn;  


function scrollToBottom() {
    setTimeout(function() {
        var chatContainer = $(".chat");
        chatContainer.scrollTop(chatContainer.prop("scrollHeight"));
    }, 100); 
}
function setupWebSocket() {
    conn = new WebSocket('ws://localhost:8080');

    conn.onopen = function(e) {
        console.log("Connection established!");
        fetchFriends(); 
    };
    conn.onmessage = function(e) {
        var data = JSON.parse(e.data);
        switch (data.type) {
            case 'new_message':
            appendMessage(data.data);
            break;
            case 'messages':
                displayMessages(data.data);
                break;
            case 'friends':
                displayFriends(data.data);
                break;
            default:
                console.error('Unhandled data type:', data.type);
        }
    };
    

    conn.onerror = function(e) {
        console.error("WebSocket error observed:", e);
    };
}

function fetchFriends() {
    var userId = $("#current_user").val(); 
    conn.send(JSON.stringify({action: 'fetchFriends', userId: userId}));
}

function displayFriends(friends) {
    $("#AppendFriendList").empty(); 
    if (friends.length > 0) {
        friends.forEach(function(friend) {
            var friendImage = friend.friendPicture ? './../uploads/' + friend.friendPicture : './../assets/img/profile.png'; 
            var fullName = friend.firstfriendName + ' ' + friend.lastfriendName;
            var friendElement = `
                <li class="active bounceInDown" data-conversation-id="${friend.conversationId}">
                    <a href="#" class="clearfix">
                        <img src="${friendImage}" alt="" class="img-circle">
                        <div class="friend-name">
                            <strong>${fullName}</strong>
                        </div>
                        <div class="last-message text-muted">${friend.lastMessage || 'Start a conversation'}</div>
                        <small class="time text-muted">${friend.lastMessageTime || 'Now'}</small>
                        <small class="chat-alert label label-danger">${friend.unreadCount || ''}</small>
                    </a>
                </li>`;
            $("#AppendFriendList").append(friendElement);
        });

        $("#AppendFriendList li").on('click', function() {
            var conversationId = $(this).data('conversation-id');
            $("#current_conversation_id").val(conversationId);
            loadMessages(conversationId);
        });
    } else {
        $("#AppendFriendList").html('<li>No friends found.</li>');
    }
}

function loadMessages(conversationId) {
    $("#displayTextArea").css("display", "block");
    conn.send(JSON.stringify({action: 'fetchMessages', conversationId: conversationId}));
}

function displayMessages(messages) {
    var current_user = $("#current_user").val();
    $(".chat").empty();
    messages.forEach(function(message) {
        appendMessage(message, current_user);
    });
    scrollToBottom();
}

function appendMessage(message) {
    console.log('New message received:', message);
    var current_user = $("#current_user").val();
    var side = message.sender_id == current_user ? 'right' : 'left';
    var imgURL = message.profilePicture ? './../uploads/' + message.profilePicture : './../assets/img/profile.png';
    var chatMessage = `
        <li class="${side} clearfix">
            <span class="chat-img pull-${side}">
                <img src="${imgURL}" alt="User Avatar">
            </span>
            <div class="chat-body clearfix">
                <div class="header">
                    <strong class="primary-font">${message.firstname} ${message.lastname}</strong>
                    <small class="pull-right text-muted"><i class="fa fa-clock-o"></i> ${new Date(message.created_at).toLocaleTimeString()}</small>
                </div>
                <p>${message.message}</p>
            </div>
        </li>
    `;
    $(".chat").append(chatMessage);
    if (!message.profilePicture) {
        scrollToBottom();
    }
}

$(document).ready(function() {
    setupWebSocket();
    scrollToBottom();
    $("#displayTextArea").css("display", "none");
    $(document).on('click', '.btn-send', function() {
        var messageText = $('#message_input').val();
        var conversationId = $('#current_conversation_id').val(); 
        if (messageText.trim() !== '') {
            conn.send(JSON.stringify({
                action: 'sendMessage',
                conversationId: conversationId,
                userId: $("#current_user").val(),  
                message: messageText
            }));
            $('#message_input').val('');
        }
    });
});
