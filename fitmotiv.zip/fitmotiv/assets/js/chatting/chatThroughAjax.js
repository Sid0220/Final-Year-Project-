
function fetchTheFriends() {
    $.ajax({
        url: './../backend/function/functionHandler.php?action=fetchFriend',
        method: 'GET',
        dataType: 'json',
        success: function(data) {
            $("#AppendFriendList").empty();
            if (window.innerWidth < 768) {
                $("#AppendFriendList").css('display', 'block');
                $(".chatarea").css('display', 'none');
                $(".backbtn").css('display', 'none');
            }            
            if (data.success && data.friends.length > 0) {
                data.friends.forEach(function(friend) {
                    var friendImage = friend.friendPicture ? './../uploads/' + friend.friendPicture : './../assets/img/profile.png'; 
                    var fullName = friend.firstfriendName + ' ' + friend.lastfriendName;
                    $("#AppendFriendList").append(`<li class="active bounceInDown" data-conversation-id="${friend.conversationId}">
                        <a href="#" class="clearfix">
                          <img src="${friendImage}" alt="" class="img-circle">
                          <div class="friend-name">
                            <strong>${fullName}</strong>
                          </div>
                          <div class="last-message text-muted">${friend.lastMessage || 'Start a conversation'}</div>
                          <small class="time text-muted">${friend.lastMessageTime || 'Now'}</small>
                          <small class="chat-alert label label-danger">${friend.unreadCount || ''}</small>
                        </a>
                      </li>`);
                });
                $("#AppendFriendList li").on('click', function() {
                    var conversationId = $(this).data('conversation-id');
                    loadMessages(conversationId);
                });
            } else {
                $("#AppendFriendList").html('<li>No friends found.</li>');
            }
        },
        error: function(xhr, status, error) {
            console.error('Error fetching friends:', error);
            $("#AppendFriendList").html('<li>Error fetching friends.</li>');
        }
    });
}
function loadMessages(conversationId) {
    $("#message_input").prop("disabled", false);
    $(".btn-send").prop("disabled",false);
    $("#current_conversation_id").val(conversationId);
    $.ajax({
        url: './../backend/function/functionHandler.php?action=fetchMessages',
        method: 'GET',
        dataType: 'json',
        data: {conversationId: conversationId},
        success: function(data) {
            if (window.innerWidth < 768) {
                $("#AppendFriendList").css('display', 'none');
                $(".chatarea").css('display', 'block');
                $(".backbtn").css('display', 'block');
            }  
            var current_user = $("#current_user").val();
            $(".chat").empty();
            if (data.success) {
                data.messages.forEach(function(message) {
                    var side = message.sender_id == current_user ? 'right' : 'left';
                    var imgURL = message.senderPicture ? './../uploads/' + message.senderPicture : './../assets/img/profile.png';
                    var chatMessage = `
                        <li class="${side} clearfix">
                            <span class="chat-img pull-${side}">
                                <img src="${imgURL}" alt="User Avatar">
                            </span>
                            <div class="chat-body clearfix">
                                <div class="header">
                                    <strong class="primary-font">${message.firstname} ${message.lastname}</strong>
                                    <small class="pull-right text-muted"><i class="fa fa-clock-o"></i> ${new Date(message.created_at).toLocaleTimeString()}</small>
                                </div>
                                <p>${message.message}</p>
                            </div>
                        </li>
                    `;
                    $(".chat").append(chatMessage);
                });
            } else {
                if (data.blocked) {
                    $("#message_input").prop("disabled", true);
                    $(".btn-send").prop("disabled",true);
                    $(".chat").html(`<li>${data.message} <button onclick="unblockUser(${data.blockedUserId})">Unblock</button></li>`);
                } else {
                    $("#message_input").prop("disabled", true);
                    $(".btn-send").prop("disabled",true);
                    $(".chat").html(`<li>${data.message}</li>`);
                }
            }
        },
        error: function(xhr, status, error) {
            console.error('Error fetching messages:', error);
            $(".chat").html('<li>Error loading messages.</li>');
        }
    });
}

function unblockUser(userId) {
    $.ajax({
        url:"./../backend/function/functionHandler.php?action=unblockUser",
        method: 'POST',
        data: {
            userId: userId
        },
        dataType: 'json',
        success:function(data) {
            if(data.success){
                location.reload();
            }
        }
    })
}
function sendMessage(conversationId, messageText) {
    $.ajax({
        url: './../backend/function/functionHandler.php?action=sendMessage',
        method: 'POST',
        dataType: 'json',
        data: {
            conversationId: conversationId,
            message: messageText
        },
        success: function(data) {
            if (data.success) {
                
                loadMessages(conversationId); 
            } else {
                alert('Error sending message: ' + data.message);
            }
        },
        error: function(xhr, status, error) {
            console.error('Error sending message:', error);
        }
    });
}

$(document).ready(function() {
    $(".backbtn").css('display', 'none');
    $("#message_input").prop("disabled", true);
    $(".btn-send").prop("disabled",true);
    fetchTheFriends();
    $(document).on('click', '.btn-send', function() {
        var messageText = $('#message_input').val();
        var conversationId = $('#current_conversation_id').val(); 
        if (messageText.trim() !== '') {
            sendMessage(conversationId, messageText);
            $('#message_input').val(''); 
        }
    });
    $(document).on('click','.backbtn',function(){
        fetchTheFriends();
    })
});
