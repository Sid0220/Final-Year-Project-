<?php
session_start();
if (!isset($_SESSION['userId'])) {
    header("Location:./../index.php");
}
?>
<!doctype html>
<html lang="en">

<head>
    <title>FITMOTIV | Home</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="./../assets/css/style.css">
    <link rel="stylesheet" href="./../assets/css/lib/toastr.css">
    <link rel="stylesheet" href="./../assets/css/style.css">
</head>

<body>
    <div class="container-fluid">
        <div class="row header">
            <div class="col-12">
                <nav class="navbar navbar-expand-lg navbar-dark bg-facebook">
                    <div class="container-fluid">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <a class="navbar-brand" href="#">FITMOTIV</a>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link " href="./index.php">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="./friends.php">View Friends</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="./friendRequest.php">Friend Request <span class="badge badge-danger" id="appendNumberRequest"></span></a>
                                </li>
                                <li class="nav-item suggest_friend">
                                    <a class="nav-link" href="./suggestionFriend.php">Friend Suggestion </span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="./notification.php">Notification <span class="badge badge-danger" id="appendNumberNotification"></span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="./message.php">Message <span class="badge badge-danger" id="appendTotalMessagesCount"></span></a>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        More
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                        <li><a class="dropdown-item" href="./profile.php">Profile</a></li>
                                        <li><a class="dropdown-item" href="./logout.php">Logout</a></li>
                                    </ul>
                                </li>

                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
        </div>