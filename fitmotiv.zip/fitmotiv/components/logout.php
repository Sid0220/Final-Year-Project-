<?php
session_start();
unset($_SESSION['userId']);
unset($_SESSION['firstName']);
unset($_SESSION['lastName']);
session_destroy();
header("Location: ./../index.php");
exit;
?>
