<?php
include_once("./include/header.php");
?>

<input type="hidden" name="userId" id="getUserId" value="<?php echo $_SESSION['userId'] ?>">
<div class="row">
    <div class="col-lg-12">
        <div class="banner">
            <div class="banner_content" id="appendProfileImage">

            </div>
            <div class="banner_content_text">
                <p class="text-white banner_text"><?php echo $_SESSION['firstName'] . ' ' . $_SESSION['lastName']  ?></p>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="contact-container" id="appendUserInfo">

        </div>
    </div>
</div>
<div class="row text-center">
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12" id="date-viewer">
                    <button id="prev" class="btn btn-secondary">&#10094;</button>
                    <input type="date" id="date-input" style="display:none;">
                    <span id="today-date"></span>
                    <button id="next" class="btn btn-secondary">&#10095;</button>
                </div>
                <div class="col-12 mt-3">
                    <div class="accordion row m-0 p-2 bg-dark rounded-pill" data-section="breakfast">
                        <div class="col-6 col-sm-6 m-0 p-0 text-start text-white">
                            <button class="toggle-button btn btn-success rounded-pill" data-target="#myModalBreakfast" data-section="breakfast">+</button>
                            <span>BREAKFAST</span>
                        </div>
                        <div class="col-6 col-sm-6 m-0 p-0 text-white">
                            <span class="kcal">0 (KCAL)</span>
                            <span class="protg">0.0 (PROTg)</span>
                        </div>
                    </div>
                    <div class="panel" data-section="breakfast">
                        <div class="row">
                            <div class="col-6 col-sm-6 m-0 pl-2 text-start ">
                                <span>No Data</span>
                            </div>
                            <div class="col-6 col-sm-6 m-0 p-0 ">
                                <span>0 (KCAL)</span>
                                <span>0.0 (PROTg)</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 mt-2">
                    <div class="accordion row m-0 p-2 bg-dark rounded-pill" data-section="lunch">
                        <div class="col-6 col-sm-6 m-0 p-0 text-start text-white">
                            <button class="toggle-button btn btn-success rounded-pill" data-target="#myModalLunch" data-section="lunch">+</button>
                            <span>LUNCH</span>
                        </div>
                        <div class="col-6 col-sm-6 m-0 p-0 text-white">
                            <span class="kcal">0 (KCAL)</span>
                            <span class="protg">0.0 (PROTg)</span>
                        </div>
                    </div>
                    <div class="panel" data-section="lunch">
                        <div class="row">
                            <div class="col-6 col-sm-6 m-0 pl-2 text-start ">
                                <span>No Data</span>
                            </div>
                            <div class="col-6 col-sm-6 m-0 p-0 ">
                                <span>0 (KCAL)</span>
                                <span>0.0 (PROTg)</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 mt-2">
                    <div class="accordion row m-0 p-2 bg-dark rounded-pill" data-section="dinner">
                        <div class="col-6 col-sm-6 m-0 p-0 text-start text-white">
                            <button class="toggle-button btn btn-success rounded-pill" data-target="#myModalLunch" data-section="dinner">+</button>
                            <span>DINNER</span>
                        </div>
                        <div class="col-6 col-sm-6 m-0 p-0 text-white">
                            <span class="kcal">0 (KCAL)</span>
                            <span class="protg">0.0 (PROTg)</span>
                        </div>
                    </div>
                    <div class="panel" data-section="dinner">
                        <div class="row">
                            <div class="col-6 col-sm-6 m-0 pl-2 text-start ">
                                <span>NO Data</span>
                            </div>
                            <div class="col-6 col-sm-6 m-0 p-0 ">
                                <span>0 (KCAL)</span>
                                <span>0.0 (PROTg)</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 mt-2">
                    <div class="accordion row m-0 p-2 bg-dark rounded-pill" data-section="snacks">
                        <div class="col-6 col-sm-6 m-0 p-0 text-start text-white">
                            <button class="toggle-button btn btn-success rounded-pill" data-target="#myModalLunch" data-section="snacks">+</button>
                            <span>SNACKS</span>
                        </div>
                        <div class="col-6 col-sm-6 m-0 p-0 text-white">
                            <span class="kcal">0 (KCAL)</span>
                            <span class="protg">0.0 (PROTg)</span>
                        </div>
                    </div>
                    <div class="panel" data-section="snacks">
                        <div class="row">
                            <div class="col-6 col-sm-6 m-0 pl-2 text-start ">
                                <span>NO Data</span>
                            </div>
                            <div class="col-6 col-sm-6 m-0 p-0 ">
                                <span>0 (KCAL)</span>
                                <span>0.0 (PROTg)</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12" id="appendPost">
    </div>
</div>

<div class="modal fade" id="editProfileModal">
    <div class="modal-dialog">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Edit Profile</h4>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">&times;</button>
            </div>

            <div class="modal-body">
                <form id="editProfileForm">
                    <div class="text-center mb-3">
                        <img src="./../assets/img/profile.png" alt="Profile Picture" id="profilePicture" class="img-fluid rounded-circle" style="width: 100px; height: 100px;">
                        <input type="file" id="profilePictureInput" name="profilePicture" accept="image/png, image/jpeg" style="display: none;" />
                        <div class="mt-2">
                            <button class="btn btn-sm btn-primary" type="button" id="editPictureButton">Edit Picture</button>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="bioTextarea">Bio:</label>
                        <textarea class="form-control" id="bioTextarea" name="bio" rows="3"></textarea>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<div class="modal fade" id="myModal">
    <div class="modal-dialog">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Details</h4>
                <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
                <form id="dietSubmit">
                    <input type="hidden" name="section" id="section">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="form-group">
                                <label for="date">Date</label>
                                <input type="date" class="form-control" name="date" id="date" placeholder="">
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" class="form-control" name="name" id="name" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="KCAL">KCAL</label>
                                <input type="text" class="form-control" name="KCAL" id="KCAL" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="PROTg">PROTg</label>
                                <input type="text" class="form-control" name="PROTg" id="PROTg" required>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <button type="submit" class="btn btn-success">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</div>


<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Bootstrap Bundle JS (includes Popper) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- jQuery first -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>




<script src="./../assets/js/lib/toastr.js"></script>
<script src="./../assets/js/post/userProfileData.js"></script>
<script src="./../assets/js/common.js"></script>
</body>

</html>