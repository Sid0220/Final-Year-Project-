<?php
include_once("./include/header.php");
?>
<div class="row bg_friend"  id="friends">
    
       
    
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
<script src="./../assets/js/lib/jquery.min.js"></script>
<script src="./../assets/js/lib/toastr.js"></script>
<script src="./../assets/js/friend/friends.js"></script>
<script src="./../assets/js/common.js"></script>
</body>

</html>