<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
<div class="col-lg-12 mt-2">
  <ul class="nav nav-tabs" id="movieTab" role="tablist">
    <li class="nav-item">
      <a class="nav-link active" id="add-movie-tab" data-toggle="tab" href="#addMovie" role="tab" aria-controls="addMovie" aria-selected="true">Add User</a>
    </li>
   
  </ul>
  <div class="tab-content" id="movieTabContent">
    <div class="tab-pane fade show active" id="addMovie" role="tabpanel" aria-labelledby="add-movie-tab">
      <div class="row">
        <div class="col-lg-12">
          <div class="card custom_card_menu">
            <div class="card-body text-white">
              <h5 class="card-title text-center card-header">View User</h5>
              <div class="table-responsive">
                <table class="table" id="userViewTable">
                  <thead>
                    <tr>
                      <th scope="col">First Name</th>
                      <th scope="col">Last Name</th>
                      <th scope="col">Email</th>
                      <th scope="col">Bio</th>
                      <th scope="col">Country</th>
                      <th scope="col">City</th>
                      <th scope="col">Current Weight</th>
                      <th scope="col">Target Weight</th>
                      <th scope="col">Goal</th>
                      <th scope="col">Action</th>
                    </tr>
                  </thead>

                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
  </div>
</div>
<!-- Bootstrap Modal -->


<!-- jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>

<!-- Include SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- Custom Scripts -->
<script src="./../assets/js/admin/user.js"></script>
